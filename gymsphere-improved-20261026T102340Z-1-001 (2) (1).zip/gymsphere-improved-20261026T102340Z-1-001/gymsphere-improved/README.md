# GYMSPHERE – Smart Gym Management System

## Run the app
    pip install -r requirements.txt
    python app.py            # open http://127.0.0.1:5000
Default admin: `admin` / `admin123` (demo only; change before real use).

## Lab demonstration flow

1. Sign in to the staff dashboard at `/login` with `admin` / `admin123`, then open **Overview**.
2. Add one or more membership plans.
3. Open `/member/register` in a second browser window and create a member account. You can also match an existing admin-created member using the same email and phone.
4. In the member portal, choose a plan under **Membership & payments**. Checkout is simulated for the lab: it stores a payment record and activates the plan without charging money or collecting card details.
5. On the fake QR checkout page, click **I have completed the demo payment**. This records the payment and activates the linked membership together.
6. Show **My profile**, **My attendance**, **Exercises**, and **My workouts**. Starting an exercise creates that day’s workout category in the log.
7. Return to staff login; open **Members**, view the member profile, and show its plan, attendance and payment history. The **Record payment** dialog records the selected plan price and activates the plan.

Member pages: `/member/login`, `/member/register`. Staff pages: `/login`.
Demo member: `demo.member@gymsphere.local` / `member123`. Run `python app.py --seed-demo` once to add the presentation dataset if it is missing.
The project uses SQLite for local demonstration. The Flask persistence layer is in `db.py`; its database is stored in `backend/data/gymsphere.db` by default. See `backend/schema.sql` for the schema and `backend/README.md` for setup notes. Set the Flask `DATABASE` config value to use a different SQLite database file.

## Run the tests
    python -m pytest                                                     # all 213 tests
    python -m pytest --cov=app --cov=validators --cov=db --cov-branch    # with coverage
    python -m pytest -m bva        # one technique: unit, whitebox, integration, blackbox, bva, ep, system, regression

## Layout
app.py (routes) · db.py (SQLite persistence) · backend/ (database file and SQL schema) · validators.py (input rules) · templates/ · tests/ (one file per test technique)

## Website capabilities

- React-powered live staff overview with animated KPI cards and JSON data from Flask.
- Staff login, member and plan management, assignment, attendance desk, workout selection/analytics and payment records.
- Member registration and login, personal dashboard, profile photo page, exercise library with local photo assets, QR checkout simulation, attendance check-in/history and workout history.
- Member detail view for staff, with membership, attendance and payment history plus a payment-record dialog.
- Responsive layout and labeled forms for desktop and mobile presentation.
