"""END-TO-END TESTS - linked member portal, QR demo payment, and staff records."""
import pytest

from conftest import add_member, add_plan, member_data

pytestmark = pytest.mark.integration


def create_member_account(client, n=1):
    data = member_data(n)
    data.update({"password": "member123", "confirm_password": "member123"})
    return client.post("/member/register", data=data)


def test_member_qr_payment_activates_membership_and_unlocks_features(client, conn):
    """Register -> choose plan -> QR confirmation -> payment/membership -> attendance/workout stay linked."""
    client.post("/login", data={"username": "admin", "password": "admin123"})
    add_plan(client, "Monthly", 30, 1500)
    client.get("/logout")

    assert create_member_account(client).status_code == 302
    start = client.post("/portal/payments", data={"plan_id": 1, "method": "Demo UPI"})
    assert start.status_code == 302 and start.headers["Location"].endswith("/portal/payments/checkout")
    assert conn.execute("SELECT COUNT(*) FROM membership").fetchone()[0] == 0
    checkout = client.get("/portal/payments/checkout")
    assert checkout.status_code == 200 and b"Demo QR checkout" in checkout.data
    assert client.post("/portal/payments/checkout").status_code == 302

    payment = conn.execute("SELECT * FROM payments").fetchone()
    membership = conn.execute("SELECT * FROM membership").fetchone()
    assert payment["plan_id"] == membership["plan_id"] == 1
    assert payment["amount"] == 1500 and payment["status"] == "Demo paid"
    assert membership["start_date"] == "2026-10-22" and membership["end_date"] == "2026-11-21"
    assert client.post("/portal/attendance").status_code == 302
    assert client.post("/portal/workouts", data={"category": "Cardio"}).status_code == 302
    assert conn.execute("SELECT COUNT(*) FROM attendance").fetchone()[0] == 1
    assert conn.execute("SELECT category FROM workout_selection").fetchone()[0] == "Cardio"


def test_member_renewal_starts_after_existing_plan(client, conn):
    """Renewing early creates a later plan period instead of overlapping the active one."""
    client.post("/login", data={"username": "admin", "password": "admin123"})
    add_plan(client, "Monthly", 30, 1500)
    client.get("/logout")
    create_member_account(client)
    for _ in range(2):
        client.post("/portal/payments", data={"plan_id": 1, "method": "Demo card"})
        client.post("/portal/payments/checkout")
    dates = conn.execute("SELECT start_date,end_date FROM membership ORDER BY membership_id").fetchall()
    assert [(row["start_date"], row["end_date"]) for row in dates] == [
        ("2026-10-22", "2026-11-21"), ("2026-11-22", "2026-12-22")]


def test_member_profile_and_exercise_library_are_linked(client, conn):
    """Profile photo, exercise names and exercise selection are served through the member portal."""
    client.post("/login", data={"username": "admin", "password": "admin123"})
    add_plan(client, "Monthly", 30, 1500)
    client.get("/logout")
    create_member_account(client)
    client.post("/portal/payments", data={"plan_id": 1, "method": "Demo UPI"})
    client.post("/portal/payments/checkout")

    profile = client.get("/portal/profile")
    library = client.get("/portal/exercises")
    assert profile.status_code == 200 and b"demo-member-profile.png" in profile.data
    assert library.status_code == 200 and b"Barbell Back Squat" in library.data
    assert client.post("/portal/exercises/barbell-back-squat/start").status_code == 302
    assert conn.execute("SELECT category FROM workout_selection").fetchone()[0] == "Legs"
    switched = client.post("/portal/exercises/dumbbell-bench-press/start", follow_redirects=True)
    assert switched.status_code == 200 and b"You can switch it anytime" in switched.data
    assert conn.execute("SELECT category FROM workout_selection").fetchone()[0] == "Chest"


def test_member_can_build_edit_switch_and_remove_a_personal_exercise_plan(client, conn):
    """Members own a persistent plan and may change their daily focus without losing it."""
    client.post("/login", data={"username": "admin", "password": "admin123"})
    add_plan(client, "Monthly", 30, 1500)
    client.get("/logout")
    create_member_account(client)
    client.post("/portal/payments", data={"plan_id": 1, "method": "Demo UPI"})
    client.post("/portal/payments/checkout")

    builder = client.get("/portal/exercise-plan")
    assert builder.status_code == 200
    for label in (b"Chest session", b"Back session", b"Legs session", b"Shoulders session", b"Cardio session"):
        assert label in builder.data

    added = client.post("/portal/exercise-plan/add", data={
        "category": "Shoulders", "exercise_name": "Arnold Press", "sets": "4",
        "reps": "8-10", "notes": "Control the lowering phase"})
    assert added.status_code == 302
    item = conn.execute("SELECT * FROM member_exercise_plan").fetchone()
    assert item["category"] == "Shoulders" and item["sets"] == 4

    edited = client.post(f"/portal/exercise-plan/{item['exercise_plan_id']}/edit", data={
        "category": "Back", "exercise_name": "Arnold Press", "sets": "5",
        "reps": "12", "notes": "Updated manually"})
    assert edited.status_code == 302
    item = conn.execute("SELECT * FROM member_exercise_plan").fetchone()
    assert (item["category"], item["sets"], item["reps"]) == ("Back", 5, "12")

    assert client.post(f"/portal/exercise-plan/{item['exercise_plan_id']}/start").status_code == 302
    assert conn.execute("SELECT category FROM workout_selection").fetchone()[0] == "Back"
    assert client.post("/portal/workouts", data={"category": "Cardio"}).status_code == 302
    assert conn.execute("SELECT category FROM workout_selection").fetchone()[0] == "Cardio"

    assert client.post(f"/portal/exercise-plan/{item['exercise_plan_id']}/delete").status_code == 302
    assert conn.execute("SELECT COUNT(*) FROM member_exercise_plan").fetchone()[0] == 0


def test_react_dashboard_api_uses_live_records(admin, conn):
    """The local React overview receives current member, attendance and payment data as JSON."""
    add_member(admin, 1)
    add_plan(admin, "Monthly", 30, 1500)
    admin.post("/members/1/payments", data={"plan_id": 1, "payment_date": "2026-10-22", "method": "UPI"})
    admin.post("/attendance", data={"member_id": 1})
    response = admin.get("/api/dashboard")
    data = response.get_json()
    assert response.status_code == 200
    assert data["stats"] == {"members": 1, "active": 1, "checkins": 1, "revenue": 1500.0}
    assert data["checkins"][0]["name"] == "Rahul Sharma"
    assert data["payments"][0]["plan_name"] == "Monthly"
    assert admin.get("/dashboard").status_code == 200


def test_admin_payment_links_selected_plan_to_membership(admin, conn):
    """Staff payment entry uses the selected plan's price and activates that member's plan."""
    add_member(admin, 1)
    add_plan(admin, "Quarterly", 90, 3999)
    response = admin.post("/members/1/payments", data={"plan_id": 1, "payment_date": "2026-10-22", "method": "UPI"})
    assert response.status_code == 302
    payment = conn.execute("SELECT * FROM payments").fetchone()
    membership = conn.execute("SELECT * FROM membership").fetchone()
    assert payment["amount"] == 3999 and payment["plan_id"] == membership["plan_id"] == 1


@pytest.mark.parametrize("path", ["/portal", "/portal/attendance", "/portal/workouts", "/portal/exercises", "/portal/exercise-plan", "/portal/payments", "/portal/payments/checkout"])
def test_member_pages_require_member_login(client, path):
    """Every member-only page redirects visitors to member login."""
    response = client.get(path)
    assert response.status_code == 302 and response.headers["Location"].endswith("/member/login")
