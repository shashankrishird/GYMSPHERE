"""BLACK-BOX TESTS - derived from the SRS requirements (FR1-FR4, NFR2-NFR3); only HTTP in, HTTP out."""
import time
import pytest
from conftest import add_member, add_plan, assign, checkin, member_data
import db as dbm

pytestmark = pytest.mark.blackbox


# FR1 Admin login
def test_bb_fr1_valid_login(client):
    """FR1: valid credentials log the admin in and show the members page."""
    r = client.post("/login", data={"username": "admin", "password": "admin123"}, follow_redirects=True)
    assert r.status_code == 200 and "Members" in r.get_data(as_text=True)


def test_bb_fr1_invalid_login_message(client):
    """FR1: wrong password shows an error and no access."""
    r = client.post("/login", data={"username": "admin", "password": "nope"})
    assert r.status_code == 401 and "Invalid username or password" in r.get_data(as_text=True)
    assert client.get("/members").status_code == 302


def test_bb_fr1_logout(admin):
    """FR1: after logout the admin pages are no longer reachable."""
    admin.get("/logout")
    assert admin.get("/plans").status_code == 302


# FR2 Member management
def test_bb_fr2_add_member_appears_in_list(admin):
    """FR2: a valid member is added and listed."""
    assert add_member(admin, 1).status_code == 302
    assert "Rahul Sharma" in admin.get("/members").get_data(as_text=True)


@pytest.mark.parametrize("field,value", [("name", ""), ("name", "R2"), ("phone", "12345"), ("email", "bad"),
                                         ("join_date", "2099-01-01"), ("join_date", "xx")],
                         ids=lambda x: str(x) or "empty")
def test_bb_fr2_invalid_member_rejected(admin, conn, field, value):
    """FR2: invalid member data is rejected with 400 and nothing is stored."""
    assert add_member(admin, 1, **{field: value}).status_code == 400
    assert conn.execute("SELECT COUNT(*) FROM members").fetchone()[0] == 0


def test_bb_fr2_duplicate_email_rejected(admin):
    """FR2: the same email (even in different case) cannot be used twice."""
    add_member(admin, 1)
    assert admin.post("/members/add", data=member_data(2, email="M1@EXAMPLE.COM")).status_code == 409


def test_bb_fr2_edit_member(admin):
    """FR2: edited details are saved."""
    add_member(admin, 1)
    admin.post("/members/1/edit", data=member_data(1, name="Rahul Verma"))
    assert "Rahul Verma" in admin.get("/members").get_data(as_text=True)


def test_bb_fr2_delete_member(admin):
    """FR2: deleted member disappears from the list."""
    add_member(admin, 1); admin.post("/members/1/delete")
    assert "Rahul Sharma" not in admin.get("/members").get_data(as_text=True)


@pytest.mark.parametrize("q,found", [("9876543201", True), ("m1@exam", True), ("sharma", True), ("zzz", False)],
                         ids=["by-phone", "by-email", "by-name-ci", "no-match"])
def test_bb_fr2_search(admin, q, found):
    """FR2: search matches name, phone or email and shows nothing for unknown text."""
    add_member(admin, 1)
    assert ("Rahul Sharma" in admin.get(f"/members?q={q}").get_data(as_text=True)) is found


# FR3 Plans
def test_bb_fr3_create_plan(admin):
    """FR3: a valid plan is created and listed."""
    assert add_plan(admin, "Quarterly", 90, 4000).status_code == 302
    assert "Quarterly" in admin.get("/plans").get_data(as_text=True)


@pytest.mark.parametrize("name,days,price", [("", 30, 1000), ("A", 30, 1000), ("OK", "abc", 1000),
                                             ("OK", 30, "free"), ("OK", 0, 1000), ("OK", 30, 0)],
                         ids=["empty-name", "short-name", "text-days", "text-price", "zero-days", "zero-price"])
def test_bb_fr3_invalid_plan_rejected(admin, name, days, price):
    """FR3: invalid plan data is rejected."""
    assert add_plan(admin, name, days, price).status_code == 400


def test_bb_fr3_duplicate_plan_name(admin):
    """FR3: plan names are unique."""
    add_plan(admin); assert add_plan(admin).status_code == 409


def test_bb_fr3_edit_and_delete_plan(admin):
    """FR3: plan can be edited and then deleted when unused."""
    add_plan(admin)
    admin.post("/plans/1/edit", data={"name": "Monthly Plus", "duration_days": 31, "price": 1700})
    assert "Monthly Plus" in admin.get("/plans").get_data(as_text=True)
    admin.post("/plans/1/delete")
    assert "Monthly Plus" not in admin.get("/plans").get_data(as_text=True)


# FR4 Attendance
def test_bb_fr4_attendance_recorded_with_date_time(ready):
    """FR4: successful check-in shows member, date and time in the list."""
    checkin(ready, 1)
    html = ready.get("/attendance").get_data(as_text=True)
    assert "Rahul Sharma" in html and "2026-10-22" in html


@pytest.mark.parametrize("mid,code", [("abc", 400), ("", 400), ("-1", 400), ("999", 404)],
                         ids=["text", "empty", "negative", "unknown"])
def test_bb_fr4_invalid_member_id(admin, mid, code):
    """FR4: invalid member ids are refused with a clear status."""
    assert checkin(admin, mid).status_code == code


def test_bb_fr4_no_double_checkin(ready):
    """FR4: only one attendance record per member per day."""
    checkin(ready, 1)
    assert checkin(ready, 1).status_code == 409


# NFR2 Security / NFR3 Performance
def test_bb_nfr2_password_not_stored_in_plain_text(app):
    """NFR2: the admin password is stored hashed, not as plain text."""
    c = dbm.connect(app.config["DATABASE"])
    stored = c.execute("SELECT password FROM admin").fetchone()[0]
    c.close()
    assert stored != "admin123" and stored.startswith(("scrypt:", "pbkdf2:"))


@pytest.mark.parametrize("payload", ["' OR '1'='1", "admin'--", "' OR 1=1 --"], ids=["or-true", "comment", "or-1"])
def test_bb_nfr2_sql_injection_in_login(client, payload):
    """NFR2: classic SQL-injection strings do not log in."""
    r = client.post("/login", data={"username": payload, "password": payload})
    assert r.status_code == 401 and client.get("/members").status_code == 302


def test_bb_nfr2_sql_injection_in_search(admin):
    """NFR2: SQL-injection text in the search box is treated as data."""
    add_member(admin, 1)
    r = admin.get("/members?q=' OR '1'='1")
    assert r.status_code == 200 and "Rahul Sharma" not in r.get_data(as_text=True)


def test_bb_nfr2_search_text_is_html_escaped(admin):
    """NFR2: script text in the search box is escaped (no XSS)."""
    html = admin.get('/members?q="><script>alert(1)</script>').get_data(as_text=True)
    assert "<script>alert(1)</script>" not in html


def test_bb_nfr3_member_list_fast_with_500_members(admin, conn):
    """NFR3: listing 500 members responds in under 1 second."""
    conn.executemany("INSERT INTO members(name,phone,email,join_date) VALUES(?,?,?,?)",
                     [(f"Member {chr(65 + i % 26)}x", f"9{i:09d}", f"u{i}@example.com", "2026-10-01") for i in range(500)])
    conn.commit()
    t = time.perf_counter(); r = admin.get("/members"); dt = time.perf_counter() - t
    assert r.status_code == 200 and dt < 1.0
