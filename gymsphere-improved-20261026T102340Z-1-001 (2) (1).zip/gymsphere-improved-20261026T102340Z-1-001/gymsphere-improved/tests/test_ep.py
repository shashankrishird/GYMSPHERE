"""EQUIVALENCE PARTITIONING - one representative per valid / invalid class."""
import pytest
import validators as v
from datetime import date

pytestmark = pytest.mark.ep
T = date(2026, 10, 22)

NAME = [("Rahul Sharma", True, "valid: letters+space"), ("O'Neil-Smith Jr.", True, "valid: . ' -"),
        ("Rahul99", False, "invalid: digits"), ("Rahul@", False, "invalid: symbol"),
        ("", False, "invalid: empty"), ("     ", False, "invalid: only spaces"),
        ("1Rahul", False, "invalid: starts with digit")]
PHONE = [("9876543210", True, "valid"), ("98765abcde", False, "invalid: letters"),
         ("98765 4321", False, "invalid: space inside"), ("0123456789", False, "invalid: starts 0"),
         ("", False, "invalid: empty"), ("+919876543210", False, "invalid: country code")]
EMAIL = [("rahul@example.com", True, "valid"), ("rahul.example.com", False, "invalid: no @"),
         ("rahul@", False, "invalid: no domain"), ("rahul@example", False, "invalid: no TLD"),
         ("@example.com", False, "invalid: no local part"), ("ra hul@example.com", False, "invalid: space"),
         ("", False, "invalid: empty")]
DATES = [("2026-10-01", True, "valid past date"), ("22-10-2026", False, "invalid: wrong format"),
         ("2026-13-01", False, "invalid: month 13"), ("2026-02-30", False, "invalid: 30 Feb"),
         ("abc", False, "invalid: text"), ("", False, "invalid: empty"), ("2030-01-01", False, "invalid: future")]
DUR = [("30", True, "valid integer"), (" 30 ", True, "valid with spaces"), ("abc", False, "invalid: text"),
       ("10.5", False, "invalid: decimal"), ("", False, "invalid: empty"), ("-5", False, "invalid: negative")]
PRICE = [("1500", True, "valid integer"), ("1500.75", True, "valid decimal"), ("abc", False, "invalid: text"),
         ("-100", False, "invalid: negative"), ("", False, "invalid: empty"), ("nan", False, "invalid: NaN")]


def p(rows): return [pytest.param(a, b, id=c) for a, b, c in rows]


@pytest.mark.parametrize("value,valid", p(NAME))
def test_ep_name(value, valid):
    """Member name equivalence classes."""
    assert (v.validate_name(value) is None) is valid


@pytest.mark.parametrize("value,valid", p(PHONE))
def test_ep_phone(value, valid):
    """Phone number equivalence classes."""
    assert (v.validate_phone(value) is None) is valid


@pytest.mark.parametrize("value,valid", p(EMAIL))
def test_ep_email(value, valid):
    """Email equivalence classes."""
    assert (v.validate_email(value) is None) is valid


@pytest.mark.parametrize("value,valid", p(DATES))
def test_ep_join_date(value, valid):
    """Join date equivalence classes."""
    assert (v.validate_join_date(value, T) is None) is valid


@pytest.mark.parametrize("value,valid", p(DUR))
def test_ep_duration(value, valid):
    """Plan duration equivalence classes."""
    assert (v.validate_duration(value) is None) is valid


@pytest.mark.parametrize("value,valid", p(PRICE))
def test_ep_price(value, valid):
    """Plan price equivalence classes."""
    assert (v.validate_price(value) is None) is valid


@pytest.mark.parametrize("name,pw,code", [
    ("admin", "admin123", 302), ("admin", "wrongpass", 401), ("nobody", "admin123", 401),
    ("", "admin123", 400), ("admin", "", 400), ("", "", 400)],
    ids=["valid-both", "valid-user-bad-pw", "unknown-user", "empty-user", "empty-pw", "both-empty"])
def test_ep_login_credentials(client, name, pw, code):
    """Login credential classes: valid / wrong password / unknown user / empty fields."""
    assert client.post("/login", data={"username": name, "password": pw}).status_code == code
