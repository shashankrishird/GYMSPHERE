import json, os, time
from datetime import date
import pytest
from app import create_app
import db as dbm

TODAY = date(2026, 10, 22)
_results = []


@pytest.fixture
def app(tmp_path):
    return create_app({"DATABASE": str(tmp_path / "t.db"), "TESTING": True,
                       "TODAY": TODAY, "SECRET_KEY": "test"})


@pytest.fixture
def client(app):
    return app.test_client()


@pytest.fixture
def admin(client):
    r = client.post("/login", data={"username": "admin", "password": "admin123"})
    assert r.status_code == 302
    return client


@pytest.fixture
def conn(app):
    c = dbm.connect(app.config["DATABASE"])
    yield c
    c.close()


def member_data(n=1, **over):
    d = {"name": "Rahul Sharma", "phone": f"98765432{n:02d}", "email": f"m{n}@example.com",
         "join_date": "2026-10-01"}
    d.update(over)
    return d


def add_member(c, n=1, **over):
    return c.post("/members/add", data=member_data(n, **over))


def add_plan(c, name="Monthly", days=30, price=1500):
    return c.post("/plans/add", data={"name": name, "duration_days": days, "price": price})


def assign(c, mid=1, pid=1, start=None):
    data = {"plan_id": pid}
    if start is not None:
        data["start_date"] = start
    return c.post(f"/members/{mid}/assign", data=data)


def checkin(c, mid=1):
    return c.post("/attendance", data={"member_id": mid})


@pytest.fixture
def ready(admin):
    """Logged-in admin with member #1 and plan #1 (30 days) and plan assigned today."""
    add_member(admin, 1); add_plan(admin); assign(admin, 1, 1)
    return admin


# ---- result collection for the lab report ----
def pytest_runtest_makereport(item, call):
    if call.when != "call" and not (call.when == "setup" and call.excinfo):
        return
    outcome = "passed"
    err = ""
    if call.excinfo:
        outcome = "failed"
        err = str(call.excinfo.value).splitlines()[0][:200] if str(call.excinfo.value) else call.excinfo.typename
    marks = [m.name for m in item.iter_markers() if m.name in
             ("unit", "bva", "ep", "whitebox", "integration", "blackbox", "system", "regression")]
    params = {}
    if hasattr(item, "callspec"):
        params = {k: (v if isinstance(v, (int, float, str, bool, type(None))) else str(v))
                  for k, v in item.callspec.params.items()}
    _results.append({"id": item.nodeid, "name": item.name, "file": item.fspath.basename,
                     "type": marks[0] if marks else "", "doc": (item.function.__doc__ or "").strip(),
                     "params": params, "outcome": outcome, "error": err})


def pytest_sessionfinish(session, exitstatus):
    path = os.environ.get("RESULTS_JSON")
    if path:
        with open(path, "w") as f:
            json.dump(_results, f, indent=1, ensure_ascii=False)
