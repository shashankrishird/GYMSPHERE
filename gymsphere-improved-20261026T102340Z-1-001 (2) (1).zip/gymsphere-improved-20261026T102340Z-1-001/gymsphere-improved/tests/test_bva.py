"""BOUNDARY VALUE ANALYSIS - min-1, min, min+1, max-1, max, max+1 for every bounded input."""
from datetime import date, timedelta
import pytest
import validators as v
from conftest import add_member, add_plan, assign, checkin, TODAY

pytestmark = pytest.mark.bva
T = date(2026, 10, 22)


def ok(msg): return msg is None


@pytest.mark.parametrize("n,valid", [(1, False), (2, True), (3, True), (49, True), (50, True), (51, False)],
                         ids=lambda x: str(x))
def test_bva_name_length(n, valid):
    """Member name length boundary: valid range is 2-50 characters."""
    assert ok(v.validate_name("A" * n)) is valid


@pytest.mark.parametrize("phone,valid", [("987654321", False), ("9876543210", True), ("98765432100", False)],
                         ids=["9-digits", "10-digits", "11-digits"])
def test_bva_phone_length(phone, valid):
    """Phone length boundary: exactly 10 digits."""
    assert ok(v.validate_phone(phone)) is valid


@pytest.mark.parametrize("phone,valid", [("5876543210", False), ("6876543210", True),
                                         ("9876543210", True)], ids=["starts-5", "starts-6", "starts-9"])
def test_bva_phone_first_digit(phone, valid):
    """Phone first-digit boundary: must be 6-9."""
    assert ok(v.validate_phone(phone)) is valid


@pytest.mark.parametrize("local_len,valid", [(88, True), (89, False)], ids=["email-100-chars", "email-101-chars"])
def test_bva_email_length(local_len, valid):
    """Email length boundary: at most 100 characters in total."""
    assert ok(v.validate_email("a" * local_len + "@example.com")) is valid


@pytest.mark.parametrize("n,valid", [(1, False), (2, True), (3, True), (29, True), (30, True), (31, False)],
                         ids=lambda x: str(x))
def test_bva_plan_name_length(n, valid):
    """Plan name length boundary: valid range is 2-30 characters."""
    assert ok(v.validate_plan_name("P" * n)) is valid


@pytest.mark.parametrize("d,valid", [(0, False), (1, True), (2, True), (364, True), (365, True), (366, False)],
                         ids=lambda x: str(x))
def test_bva_plan_duration(d, valid):
    """Plan duration boundary: valid range is 1-365 days."""
    assert ok(v.validate_duration(d)) is valid


@pytest.mark.parametrize("p,valid", [(0, False), (0.99, False), (1, True), (1.01, True),
                                     (99999, True), (100000, True), (100000.01, False)], ids=lambda x: str(x))
def test_bva_plan_price(p, valid):
    """Plan price boundary: valid range is 1-100000."""
    assert ok(v.validate_price(p)) is valid


@pytest.mark.parametrize("n,valid", [(5, False), (6, True), (7, True)], ids=lambda x: str(x))
def test_bva_password_length(n, valid):
    """Password length boundary: minimum 6 characters."""
    assert ok(v.validate_password("x" * n)) is valid


@pytest.mark.parametrize("delta,valid", [(-1, True), (0, True), (1, False)], ids=["yesterday", "today", "tomorrow"])
def test_bva_join_date(delta, valid):
    """Join date boundary: today and earlier are valid, tomorrow is not."""
    d = (T + timedelta(days=delta)).isoformat()
    assert ok(v.validate_join_date(d, T)) is valid


def test_bva_leap_day():
    """Date boundary: 29 Feb exists only in leap years."""
    assert v.parse_date("2028-02-29") is not None
    assert v.parse_date("2026-02-29") is None


# ---- boundaries through the HTTP layer (membership validity window) ----
@pytest.mark.parametrize("offset,expected", [(-1, 403), (0, 200), (1, 200)], ids=["day-before-start", "start-day", "day-after-start"])
def test_bva_membership_start_boundary(app, admin, offset, expected):
    """Check-in boundary at membership start date (start = 2026-10-22)."""
    add_member(admin, 1); add_plan(admin, days=30); assign(admin, 1, 1, TODAY.isoformat())
    app.config["TODAY"] = TODAY + timedelta(days=offset)
    r = checkin(admin, 1)
    assert (200 if r.status_code == 302 else r.status_code) == expected


@pytest.mark.parametrize("offset,expected", [(29, 200), (30, 200), (31, 403)], ids=["end-1", "end-day", "end+1"])
def test_bva_membership_end_boundary(app, admin, offset, expected):
    """Check-in boundary at membership end date (30-day plan, end = start + 30)."""
    add_member(admin, 1); add_plan(admin, days=30); assign(admin, 1, 1, TODAY.isoformat())
    app.config["TODAY"] = TODAY + timedelta(days=offset)
    r = checkin(admin, 1)
    assert (200 if r.status_code == 302 else r.status_code) == expected


@pytest.mark.parametrize("days,code", [(0, 400), (1, 302), (365, 302), (366, 400)], ids=lambda x: str(x))
def test_bva_plan_duration_via_form(admin, days, code):
    """Plan duration boundaries enforced by the /plans/add form."""
    assert add_plan(admin, days=days).status_code == code
