"""REGRESSION TESTS - each test pins a defect found during testing so it can never come back."""
import pytest
import validators as v
from conftest import add_member, add_plan, assign, checkin, member_data

pytestmark = pytest.mark.regression


def test_rg_d1_non_ascii_digits_rejected_in_phone():
    """D1: a phone written with Devanagari/Arabic-Indic digits must be rejected (only 0-9 allowed)."""
    assert v.validate_phone("9" + "०" * 9) is not None      # 9 + 9 Devanagari zeros
    assert v.validate_phone("9" + "٠" * 9) is not None      # 9 + 9 Arabic-Indic zeros


def test_rg_d1_non_ascii_digits_rejected_in_duration():
    """D1b: plan duration given in non-ASCII digits is rejected."""
    assert v.validate_duration("٣٠") is not None       # Arabic-Indic '30'


def test_rg_d2_invalid_start_date_rejected(admin, conn):
    """D2: assigning a plan with a malformed start date must be refused, not silently use today."""
    add_member(admin, 1); add_plan(admin)
    r = assign(admin, 1, 1, "not-a-date")
    assert r.status_code == 400
    assert conn.execute("SELECT COUNT(*) FROM membership").fetchone()[0] == 0


def test_rg_d3_lockout_survives_new_session(app, client):
    """D3: login lockout must be enforced on the server; discarding the cookie must not reset it."""
    for _ in range(3):
        client.post("/login", data={"username": "admin", "password": "bad"})
    fresh = app.test_client()                                    # attacker drops the session cookie
    assert fresh.post("/login", data={"username": "admin", "password": "admin123"}).status_code == 429


def test_rg_d3_successful_login_resets_counter(app):
    """D3 guard: 2 failures followed by a correct login still works, and the counter resets."""
    c = app.test_client()
    for _ in range(2):
        c.post("/login", data={"username": "admin", "password": "bad"})
    assert c.post("/login", data={"username": "admin", "password": "admin123"}).status_code == 302
    c2 = app.test_client()
    for _ in range(2):
        c2.post("/login", data={"username": "admin", "password": "bad"})
    assert c2.post("/login", data={"username": "admin", "password": "admin123"}).status_code == 302


def test_rg_d3_lock_expires(app, client):
    """D3: the lock is temporary - once locked_until has passed the admin can log in again."""
    import db as dbm
    for _ in range(3):
        client.post("/login", data={"username": "admin", "password": "bad"})
    c = dbm.connect(app.config["DATABASE"])
    c.execute("UPDATE login_attempts SET locked_until=1"); c.commit(); c.close()
    assert client.post("/login", data={"username": "admin", "password": "admin123"}).status_code == 302


def test_rg_d2_blank_start_date_defaults_to_today(admin, conn):
    """D2 guard: leaving the start date blank still means 'start today'."""
    add_member(admin, 1); add_plan(admin)
    assert assign(admin, 1, 1, "").status_code == 302
    assert conn.execute("SELECT start_date FROM membership").fetchone()[0] == "2026-10-22"


def test_rg_d1_non_ascii_price_rejected():
    """D1c: plan price written with non-ASCII digits is rejected."""
    assert v.validate_price("١٥٠٠") is not None


def test_rg_init_db_is_idempotent(app):
    """Restarting the app on an existing database keeps a single admin account (no duplicate seed)."""
    import db as dbm
    from app import create_app
    create_app({"DATABASE": app.config["DATABASE"], "TESTING": True})
    c = dbm.connect(app.config["DATABASE"])
    n = c.execute("SELECT COUNT(*) FROM admin").fetchone()[0]
    c.close()
    assert n == 1


def test_rg_app_starts_without_test_config(monkeypatch):
    """create_app() works with no test_config (production path); DB init is stubbed so no file is created."""
    import app as appmod
    monkeypatch.setattr(appmod.dbm, "init_db", lambda *a, **k: None)
    assert appmod.create_app().test_client().get("/login").status_code == 200
