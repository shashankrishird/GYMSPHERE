"""INTEGRATION TESTS - several modules working together through the real database."""
import pytest
from datetime import timedelta
from conftest import add_member, add_plan, assign, checkin, TODAY

pytestmark = pytest.mark.integration


def test_it_login_member_plan_attendance_flow(admin, conn):
    """Login -> add member -> add plan -> assign -> check in: attendance row stored with date and time."""
    add_member(admin, 1); add_plan(admin); assign(admin, 1, 1)
    assert checkin(admin, 1).status_code == 302
    row = conn.execute("SELECT * FROM attendance").fetchone()
    assert row["member_id"] == 1 and row["date"] == TODAY.isoformat() and len(row["time"]) == 8


def test_it_assign_computes_end_date(admin, conn):
    """Members + Plans: end_date = start_date + plan duration."""
    add_member(admin, 1); add_plan(admin, days=45); assign(admin, 1, 1, "2026-10-01")
    assert conn.execute("SELECT end_date FROM membership").fetchone()[0] == "2026-11-15"


def test_it_delete_member_cascades(ready, conn):
    """Deleting a member removes their memberships and attendance (FK cascade)."""
    checkin(ready, 1)
    ready.post("/members/1/delete")
    assert conn.execute("SELECT COUNT(*) FROM membership").fetchone()[0] == 0
    assert conn.execute("SELECT COUNT(*) FROM attendance").fetchone()[0] == 0


def test_it_plan_in_use_cannot_be_deleted_until_member_removed(ready, conn):
    """Plans + Members: plan in use is protected; after the member is deleted the plan can go."""
    assert ready.post("/plans/1/delete").status_code == 409
    ready.post("/members/1/delete")
    assert ready.post("/plans/1/delete").status_code == 302
    assert conn.execute("SELECT COUNT(*) FROM plans").fetchone()[0] == 0


def test_it_expired_membership_blocks_attendance(admin):
    """Plans + Attendance: a membership that ended before today cannot check in."""
    add_member(admin, 1); add_plan(admin, days=30); assign(admin, 1, 1, "2026-01-01")
    assert checkin(admin, 1).status_code == 403


def test_it_next_day_checkin_allowed(app, ready):
    """Attendance: one check-in per day, but allowed again the next day."""
    assert checkin(ready, 1).status_code == 302
    assert checkin(ready, 1).status_code == 409
    app.config["TODAY"] = TODAY + timedelta(days=1)
    assert checkin(ready, 1).status_code == 302


def test_it_edit_member_visible_in_attendance_list(ready):
    """Members + Attendance: renamed member shows the new name in the attendance table."""
    checkin(ready, 1)
    ready.post("/members/1/edit", data={"name": "Rahul Kumar", "phone": "9876543201",
                                         "email": "m1@example.com", "join_date": "2026-10-01"})
    assert "Rahul Kumar" in ready.get("/attendance").get_data(as_text=True)


def test_it_two_members_independent_attendance(admin, conn):
    """Attendance for member 1 does not block member 2."""
    add_member(admin, 1); add_member(admin, 2); add_plan(admin); assign(admin, 1, 1); assign(admin, 2, 1)
    assert checkin(admin, 1).status_code == 302 and checkin(admin, 2).status_code == 302
    assert conn.execute("SELECT COUNT(*) FROM attendance").fetchone()[0] == 2


def test_it_foreign_keys_enforced(conn):
    """Database layer: inserting attendance for a non-existent member is rejected."""
    import sqlite3
    with pytest.raises(sqlite3.IntegrityError):
        conn.execute("INSERT INTO attendance(member_id,date,time) VALUES(999,'2026-10-22','10:00:00')")


@pytest.mark.parametrize("path", ["/members", "/members/add", "/plans", "/plans/add", "/attendance"])
def test_it_all_protected_pages_require_login(client, path):
    """Login + every module: anonymous users are redirected to /login."""
    r = client.get(path)
    assert r.status_code == 302 and r.headers["Location"].endswith("/login")


@pytest.mark.parametrize("path", ["/members/1/delete", "/plans/1/delete", "/members/1/assign"])
def test_it_protected_post_actions_require_login(client, path):
    """Login + destructive POST actions are also protected."""
    assert client.post(path).status_code == 302
