"""SYSTEM TESTS - complete user scenarios from login to logout."""
import pytest
from datetime import timedelta
from conftest import add_member, add_plan, assign, checkin, TODAY

pytestmark = pytest.mark.system


def test_sys_gym_day_scenario(app, client, conn):
    """Full day: admin logs in, creates plans, registers 3 members, assigns plans, members check in, logout."""
    assert client.post("/login", data={"username": "admin", "password": "admin123"}).status_code == 302
    add_plan(client, "Monthly", 30, 1500); add_plan(client, "Yearly", 365, 12000)
    for n in (1, 2, 3):
        assert add_member(client, n, name=f"Member {'ABC'[n-1]}x").status_code == 302
    assign(client, 1, 1); assign(client, 2, 2)
    assert checkin(client, 1).status_code == 302
    assert checkin(client, 2).status_code == 302
    assert checkin(client, 3).status_code == 403          # member 3 has no plan
    assert checkin(client, 1).status_code == 409          # already checked in
    assert conn.execute("SELECT COUNT(*) FROM attendance").fetchone()[0] == 2
    client.get("/logout")
    assert client.get("/attendance").status_code == 302


def test_sys_membership_lifecycle(app, admin):
    """A member is active, then the plan expires, then is renewed and can check in again."""
    add_member(admin, 1); add_plan(admin, days=30); assign(admin, 1, 1)
    assert checkin(admin, 1).status_code == 302
    app.config["TODAY"] = TODAY + timedelta(days=40)       # plan expired
    assert checkin(admin, 1).status_code == 403
    assign(admin, 1, 1)                                     # renewal starts "today" (day 40)
    assert checkin(admin, 1).status_code == 302


def test_sys_error_pages_do_not_crash(admin):
    """Unknown ids/URLs return proper 404 instead of a server error."""
    assert admin.get("/members/999/edit").status_code == 404
    assert admin.get("/nope").status_code == 404
    assert admin.post("/members/999/delete").status_code == 404


def test_sys_session_isolated_between_clients(app, admin):
    """A logged-in browser does not give access to another browser."""
    other = app.test_client()
    assert other.get("/members").status_code == 302
    assert admin.get("/members").status_code == 200


@pytest.mark.parametrize("path", [
    "/dashboard", "/api/dashboard", "/members", "/plans", "/attendance",
    "/workouts", "/analytics", "/payments",
])
def test_sys_all_admin_showcase_pages_render(admin, path):
    """Every linked admin showcase page renders for an authenticated staff user."""
    assert admin.get(path).status_code == 200
