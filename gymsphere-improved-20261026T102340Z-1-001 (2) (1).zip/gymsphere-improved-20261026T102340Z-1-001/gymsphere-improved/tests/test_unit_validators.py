"""UNIT TESTS - validators.py (pure functions, no DB / Flask)."""
from datetime import date
import pytest
import validators as v

pytestmark = pytest.mark.unit
T = date(2026, 10, 22)


def test_valid_name_returns_none():
    """validate_name accepts a normal two-word name."""
    assert v.validate_name("Rahul Sharma") is None


def test_name_is_trimmed_before_length_check():
    """validate_name trims surrounding spaces, so '  Al  ' counts as 2 chars."""
    assert v.validate_name("  Al  ") is None


def test_name_none_is_rejected():
    """validate_name treats None like an empty string."""
    assert v.validate_name(None) is not None


def test_valid_phone():
    """validate_phone accepts a 10-digit number starting with 9."""
    assert v.validate_phone("9876543210") is None


def test_phone_none_is_rejected():
    """validate_phone rejects None."""
    assert v.validate_phone(None) is not None


def test_valid_email():
    """validate_email accepts a standard address."""
    assert v.validate_email("a.b+c@mail.example.co") is None


def test_parse_date_valid():
    """parse_date converts YYYY-MM-DD into a date object."""
    assert v.parse_date("2026-10-22") == date(2026, 10, 22)


def test_parse_date_invalid_returns_none():
    """parse_date returns None for text that is not a date."""
    assert v.parse_date("22/10/2026") is None


def test_join_date_today_ok():
    """validate_join_date accepts today's date."""
    assert v.validate_join_date("2026-10-22", T) is None


def test_join_date_future_rejected():
    """validate_join_date rejects a date after today."""
    assert "future" in v.validate_join_date("2026-10-23", T)


def test_valid_plan_fields():
    """Plan name, duration and price validators accept normal values."""
    assert v.validate_plan_name("Monthly") is None
    assert v.validate_duration("30") is None
    assert v.validate_price("1500.50") is None


def test_valid_password():
    """validate_password accepts a 6+ char password."""
    assert v.validate_password("admin123") is None


def test_password_none_rejected():
    """validate_password rejects None."""
    assert v.validate_password(None) is not None
