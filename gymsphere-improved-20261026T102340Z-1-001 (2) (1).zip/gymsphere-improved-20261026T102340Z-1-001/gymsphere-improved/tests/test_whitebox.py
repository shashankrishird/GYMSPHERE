"""WHITE-BOX TESTS - one test per branch / basis path of the main routes (see coverage report)."""
import pytest
from conftest import add_member, add_plan, assign, checkin, member_data

pytestmark = pytest.mark.whitebox


# ---- login(): V(G)=11. Paths 1-5 below; lock-expiry and counter-reset paths are in test_regression.py ----
def test_wb_login_get_renders_form(client):
    """Path 1: GET /login renders the form."""
    assert client.get("/login").status_code == 200


def test_wb_login_empty_fields(client):
    """Path 2: POST with empty fields returns 400."""
    assert client.post("/login", data={"username": "", "password": ""}).status_code == 400


def test_wb_login_wrong_password_increments_counter(client):
    """Path 3: wrong password returns 401 and counts a failure."""
    assert client.post("/login", data={"username": "admin", "password": "bad"}).status_code == 401


def test_wb_login_locked_after_three_failures(client):
    """Path 4: after 3 failures even the correct password is refused with 429."""
    for _ in range(3):
        client.post("/login", data={"username": "admin", "password": "bad"})
    assert client.post("/login", data={"username": "admin", "password": "admin123"}).status_code == 429


def test_wb_login_success(client):
    """Path 5: valid credentials redirect to /members and set the session."""
    r = client.post("/login", data={"username": "admin", "password": "admin123"})
    assert r.status_code == 302 and r.headers["Location"].endswith("/members")


def test_wb_logout_clears_session(admin):
    """logout() clears the session so protected pages redirect to login."""
    admin.get("/logout")
    assert admin.get("/members").status_code == 302


def test_wb_index_redirects_by_state(client):
    """index(): both branches (anonymous -> /login, logged-in -> /members)."""
    assert client.get("/").headers["Location"].endswith("/login")
    client.post("/login", data={"username": "admin", "password": "admin123"})
    assert client.get("/").headers["Location"].endswith("/members")


# ---- members ----
def test_wb_members_search_branch(admin):
    """members(): the 'q' search branch filters by name."""
    add_member(admin, 1, name="Rahul Sharma"); add_member(admin, 2, name="Priya Singh")
    html = admin.get("/members?q=Priya").get_data(as_text=True)
    assert "Priya Singh" in html and "Rahul Sharma" not in html


def test_wb_members_no_search_lists_all(admin):
    """members(): no 'q' branch lists everyone."""
    add_member(admin, 1, name="Rahul Sharma"); add_member(admin, 2, name="Priya Singh")
    html = admin.get("/members").get_data(as_text=True)
    assert "Priya Singh" in html and "Rahul Sharma" in html


def test_wb_add_member_get_form(admin):
    """add_member(): GET shows the empty form."""
    assert admin.get("/members/add").status_code == 200


def test_wb_add_member_validation_error(admin):
    """add_member(): validation branch returns 400."""
    assert add_member(admin, 1, name="").status_code == 400


def test_wb_add_member_duplicate_integrity_error(admin):
    """add_member(): IntegrityError branch returns 409 for duplicate phone."""
    add_member(admin, 1)
    assert admin.post("/members/add", data=member_data(2, phone=member_data(1)["phone"])).status_code == 409


def test_wb_edit_member_branches(admin):
    """edit_member(): GET form, success, validation error, duplicate, and 404 branches."""
    add_member(admin, 1); add_member(admin, 2)
    assert admin.get("/members/1/edit").status_code == 200
    assert admin.post("/members/1/edit", data=member_data(1, name="Rahul K")).status_code == 302
    assert admin.post("/members/1/edit", data=member_data(1, phone="123")).status_code == 400
    assert admin.post("/members/1/edit", data=member_data(1, phone=member_data(2)["phone"])).status_code == 409
    assert admin.get("/members/99/edit").status_code == 404


def test_wb_delete_member_branches(admin):
    """delete_member(): success and 404 branches."""
    add_member(admin, 1)
    assert admin.post("/members/1/delete").status_code == 302
    assert admin.post("/members/1/delete").status_code == 404


# ---- plans ----
def test_wb_plan_add_branches(admin):
    """add_plan(): GET, success, validation error and duplicate-name branches."""
    assert admin.get("/plans/add").status_code == 200
    assert add_plan(admin).status_code == 302
    assert add_plan(admin, name="X", days=0).status_code == 400
    assert add_plan(admin).status_code == 409


def test_wb_plan_edit_branches(admin):
    """edit_plan(): GET, success, validation, duplicate and 404 branches."""
    add_plan(admin, "Monthly"); add_plan(admin, "Yearly", 365, 12000)
    assert admin.get("/plans/1/edit").status_code == 200
    assert admin.post("/plans/1/edit", data={"name": "Monthly+", "duration_days": 31, "price": 1600}).status_code == 302
    assert admin.post("/plans/1/edit", data={"name": "Monthly+", "duration_days": 0, "price": 1600}).status_code == 400
    assert admin.post("/plans/1/edit", data={"name": "Yearly", "duration_days": 31, "price": 1600}).status_code == 409
    assert admin.get("/plans/99/edit").status_code == 404


def test_wb_plan_delete_branches(admin):
    """delete_plan(): success, in-use (409) and 404 branches."""
    add_plan(admin, "Aa"); add_plan(admin, "Bb"); add_member(admin, 1); assign(admin, 1, 2)
    assert admin.post("/plans/1/delete").status_code == 302
    assert admin.post("/plans/2/delete").status_code == 409
    assert admin.post("/plans/99/delete").status_code == 404


def test_wb_assign_branches(admin):
    """assign_plan(): unknown member 404, unknown plan 400, explicit start date, default start date."""
    add_member(admin, 1); add_plan(admin)
    assert assign(admin, 99, 1).status_code == 404
    assert assign(admin, 1, 99).status_code == 400
    assert assign(admin, 1, 1, "2026-11-01").status_code == 302
    assert assign(admin, 1, 1).status_code == 302


# ---- attendance(): predicates = POST?, isdigit?, member exists?, active?, IntegrityError? -> V(G)=6 ----
def test_wb_attendance_path1_get(admin):
    """Path 1: GET lists attendance."""
    assert admin.get("/attendance").status_code == 200


def test_wb_attendance_path2_non_numeric(admin):
    """Path 2: non-numeric member id returns 400."""
    assert checkin(admin, "abc").status_code == 400


def test_wb_attendance_path3_unknown_member(admin):
    """Path 3: unknown member returns 404."""
    assert checkin(admin, 99).status_code == 404


def test_wb_attendance_path4_no_membership(admin):
    """Path 4: member without a plan returns 403."""
    add_member(admin, 1)
    assert checkin(admin, 1).status_code == 403


def test_wb_attendance_path5_success(ready):
    """Path 5: active member is recorded and redirected."""
    assert checkin(ready, 1).status_code == 302


def test_wb_attendance_path6_duplicate(ready):
    """Path 6: second check-in on the same day returns 409 (IntegrityError branch)."""
    checkin(ready, 1)
    assert checkin(ready, 1).status_code == 409


def test_wb_login_required_decorator_blocks(client):
    """login_required: anonymous access is redirected to /login."""
    assert client.get("/plans").status_code == 302
