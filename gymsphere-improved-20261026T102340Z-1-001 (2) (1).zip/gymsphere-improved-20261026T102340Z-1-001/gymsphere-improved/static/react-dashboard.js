/* Local React overview: data comes from Flask at /api/dashboard. */
(function () {
  const root = document.getElementById("react-dashboard");
  if (!root || !window.React || !window.ReactDOM) return;
  const h = React.createElement;
  const money = (value) => "₹" + Number(value || 0).toLocaleString("en-IN", {minimumFractionDigits: 2});

  function Stat(props) {
    return h("article", {className: "react-stat-card"}, [
      h("span", {key: "label"}, props.label),
      h("strong", {key: "value"}, props.value),
      h("small", {key: "note"}, props.note)
    ]);
  }

  function ActivityList(props) {
    return h("section", {className: "react-panel"}, [
      h("div", {className: "react-panel-title", key: "title"}, [
        h("h2", {key: "heading"}, props.title),
        h("a", {href: props.href, key: "link"}, props.linkText)
      ]),
      props.items.length ? h("div", {className: "react-activity-list", key: "list"}, props.items.map((item, index) =>
        h("div", {className: "react-activity", key: index}, [
          h("span", {className: "react-activity-icon", key: "icon"}, props.icon),
          h("span", {className: "react-activity-copy", key: "copy"}, [
            h("strong", {key: "name"}, item.name),
            h("small", {key: "detail"}, props.detail(item))
          ]),
          props.amount ? h("b", {key: "amount"}, money(item.amount)) : null
        ])
      )) : h("p", {className: "empty", key: "empty"}, "No activity recorded yet.")
    ]);
  }

  function Dashboard(props) {
    const data = props.data;
    const s = data.stats;
    return h("div", {className: "react-overview"}, [
      h("section", {className: "react-hero", key: "hero"}, [
        h("div", {className: "react-hero-copy", key: "copy"}, [
          h("span", {className: "react-eyebrow", key: "eyebrow"}, "LIVE STAFF OVERVIEW · " + data.today),
          h("h1", {key: "heading"}, "A clearer view of your gym."),
          h("p", {key: "body"}, "Member plans, attendance and payment records update together across GymSphere."),
          h("div", {className: "react-hero-actions", key: "actions"}, [
            h("a", {className: "btn accent", href: "/members/add", key: "member"}, "+ Add member"),
            h("a", {className: "btn react-ghost-light", href: "/attendance", key: "attendance"}, "Open check-in desk")
          ])
        ]),
        h("div", {className: "react-hero-visual", key: "visual"}, [
          h("img", {src: "/static/images/admin-profile.png", alt: "GymSphere administrator", key: "image"}),
          h("span", {key: "badge"}, "All modules synced")
        ])
      ]),
      h("section", {className: "react-stats", key: "stats"}, [
        h(Stat, {label: "Total members", value: s.members, note: "Registered profiles", key: "members"}),
        h(Stat, {label: "Active memberships", value: s.active, note: "Valid today", key: "active"}),
        h(Stat, {label: "Today's check-ins", value: s.checkins, note: "Attendance recorded", key: "checkins"}),
        h(Stat, {label: "Payments this month", value: money(s.revenue), note: "Linked plan payments", key: "revenue"})
      ]),
      h("section", {className: "react-grid", key: "grid"}, [
        h(ActivityList, {title: "Latest check-ins", href: "/attendance", linkText: "Attendance desk", icon: "✓", items: data.checkins, detail: (row) => row.date + " · " + row.time, key: "checkins"}),
        h(ActivityList, {title: "Recent payments", href: "/payments", linkText: "All payments", icon: "₹", amount: true, items: data.payments, detail: (row) => (row.plan_name || "Plan payment") + " · " + row.payment_date, key: "payments"})
      ]),
      h("section", {className: "react-quick-links", key: "links"}, [
        h("a", {href: "/members", key: "members"}, [h("span", {key: "number"}, "01"), h("strong", {key: "title"}, "Manage members"), h("small", {key: "note"}, "Profiles, plans and receipts")]),
        h("a", {href: "/plans", key: "plans"}, [h("span", {key: "number"}, "02"), h("strong", {key: "title"}, "Membership plans"), h("small", {key: "note"}, "Prices, duration and renewals")]),
        h("a", {href: "/analytics", key: "analytics"}, [h("span", {key: "number"}, "03"), h("strong", {key: "title"}, "Workout analytics"), h("small", {key: "note"}, "Member training preferences")])
      ])
    ]);
  }

  function renderError() {
    ReactDOM.createRoot(root).render(h("section", {className: "card"}, [
      h("h1", {key: "heading"}, "Overview unavailable"),
      h("p", {key: "text"}, "Refresh this page to load the latest gym data.")
    ]));
  }

  fetch("/api/dashboard", {headers: {Accept: "application/json"}})
    .then((response) => response.ok ? response.json() : Promise.reject(response))
    .then((data) => ReactDOM.createRoot(root).render(h(Dashboard, {data: data})))
    .catch(renderError);
}());
