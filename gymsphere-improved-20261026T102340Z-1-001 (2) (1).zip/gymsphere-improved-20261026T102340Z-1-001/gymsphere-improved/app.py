"""GYMSPHERE - Smart Gym Management System (Phase 4 build: login, members, plans, attendance)."""
import os
import sqlite3
import sys
import time
from datetime import date, datetime, timedelta
from functools import wraps

from flask import (Flask, flash, g, jsonify, redirect, render_template, request,
                   session, url_for, abort)
from werkzeug.security import check_password_hash, generate_password_hash

import db as dbm
import validators as v

MAX_FAILED_LOGINS = 3
LOCK_SECONDS = 300


def create_app(test_config=None):
    app = Flask(__name__)
    app.config.update(SECRET_KEY=os.environ.get("SECRET_KEY", "dev-change-me"),
                      DATABASE=os.path.join(os.path.dirname(__file__), "backend", "data", "gymsphere.db"),
                      TODAY=None)  # tests can freeze "today"
    if test_config:
        app.config.update(test_config)
    dbm.init_db(app.config["DATABASE"])

    def today():
        return app.config["TODAY"] or date.today()

    def get_db():
        if "db" not in g:
            g.db = dbm.connect(app.config["DATABASE"])
        return g.db

    @app.teardown_appcontext
    def close_db(_):
        conn = g.pop("db", None)
        if conn is not None:
            conn.close()

    def login_required(view):
        @wraps(view)
        def wrapped(*a, **kw):
            if not session.get("admin_id"):
                return redirect(url_for("login"))
            return view(*a, **kw)
        return wrapped

    def member_required(view):
        @wraps(view)
        def wrapped(*a, **kw):
            if not session.get("member_id"):
                return redirect(url_for("member_login"))
            return view(*a, **kw)
        return wrapped

    # ---------------- FR1 Admin login ----------------
    @app.route("/")
    def index():
        if session.get("admin_id"):
            return redirect(url_for("members"))
        if session.get("member_id"):
            return redirect(url_for("member_dashboard"))
        return redirect(url_for("login"))

    @app.route("/login", methods=["GET", "POST"])
    def login():
        if request.method == "POST":
            username = request.form.get("username", "").strip()
            password = request.form.get("password", "")
            if not username or not password:
                flash("Username and password are required.", "error")
                return render_template("login.html"), 400
            db_ = get_db()
            now = time.time()
            att = db_.execute("SELECT * FROM login_attempts WHERE username=?", (username,)).fetchone()
            if att and att["locked_until"]:
                if att["locked_until"] > now:
                    flash("Too many failed attempts. Try again later.", "error")
                    return render_template("login.html"), 429
                db_.execute("DELETE FROM login_attempts WHERE username=?", (username,))   # lock expired
                db_.commit()
                att = None
            row = db_.execute("SELECT * FROM admin WHERE username=?", (username,)).fetchone()
            if row and check_password_hash(row["password"], password):
                db_.execute("DELETE FROM login_attempts WHERE username=?", (username,))
                db_.commit()
                session.clear()
                session["admin_id"] = row["admin_id"]
                return redirect(url_for("members"))
            failed = (att["failed"] if att else 0) + 1
            locked = now + LOCK_SECONDS if failed >= MAX_FAILED_LOGINS else 0
            db_.execute("INSERT INTO login_attempts(username,failed,locked_until) VALUES(?,?,?) "
                        "ON CONFLICT(username) DO UPDATE SET failed=excluded.failed, locked_until=excluded.locked_until",
                        (username, failed, locked))
            db_.commit()
            flash("Invalid username or password.", "error")
            return render_template("login.html"), 401
        return render_template("login.html")

    @app.route("/logout")
    def logout():
        session.clear()
        return redirect(url_for("login"))

    @app.route("/dashboard")
    @login_required
    def admin_dashboard():
        db_ = get_db()
        t = today()
        month_start = t.replace(day=1).isoformat()
        stats = {
            "members": db_.execute("SELECT COUNT(*) AS n FROM members").fetchone()["n"],
            "active": db_.execute("SELECT COUNT(DISTINCT member_id) AS n FROM membership WHERE start_date<=? AND end_date>=?",
                                  (t.isoformat(), t.isoformat())).fetchone()["n"],
            "checkins": db_.execute("SELECT COUNT(*) AS n FROM attendance WHERE date=?", (t.isoformat(),)).fetchone()["n"],
            "revenue": db_.execute("SELECT COALESCE(SUM(amount),0) AS n FROM payments WHERE payment_date>=? AND payment_date<=?",
                                   (month_start, t.isoformat())).fetchone()["n"],
        }
        recent_attendance = db_.execute("SELECT a.*,m.name FROM attendance a JOIN members m USING(member_id) "
                                        "ORDER BY a.date DESC,a.time DESC LIMIT 5").fetchall()
        recent_payments = db_.execute("SELECT p.*,m.name,pl.name AS plan_name FROM payments p "
                                      "JOIN members m USING(member_id) LEFT JOIN plans pl USING(plan_id) "
                                      "ORDER BY p.payment_date DESC,p.payment_id DESC LIMIT 5").fetchall()
        return render_template("admin_dashboard.html", stats=stats,
                               recent_attendance=recent_attendance, recent_payments=recent_payments,
                               today=t.isoformat())

    @app.route("/api/dashboard")
    @login_required
    def dashboard_data():
        """Small JSON endpoint consumed by the local React overview."""
        db_ = get_db()
        t = today()
        month_start = t.replace(day=1).isoformat()
        stats = {
            "members": db_.execute("SELECT COUNT(*) AS n FROM members").fetchone()["n"],
            "active": db_.execute("SELECT COUNT(DISTINCT member_id) AS n FROM membership WHERE start_date<=? AND end_date>=?",
                                  (t.isoformat(), t.isoformat())).fetchone()["n"],
            "checkins": db_.execute("SELECT COUNT(*) AS n FROM attendance WHERE date=?", (t.isoformat(),)).fetchone()["n"],
            "revenue": db_.execute("SELECT COALESCE(SUM(amount),0) AS n FROM payments WHERE payment_date>=? AND payment_date<=?",
                                   (month_start, t.isoformat())).fetchone()["n"],
        }
        checkins = db_.execute("SELECT a.date,a.time,m.name FROM attendance a JOIN members m USING(member_id) "
                               "ORDER BY a.date DESC,a.time DESC LIMIT 5").fetchall()
        payments = db_.execute("SELECT p.amount,p.payment_date,m.name,pl.name AS plan_name FROM payments p "
                               "JOIN members m USING(member_id) LEFT JOIN plans pl USING(plan_id) "
                               "ORDER BY p.payment_date DESC,p.payment_id DESC LIMIT 5").fetchall()
        return jsonify(today=t.isoformat(), stats=stats,
                       checkins=[dict(row) for row in checkins],
                       payments=[dict(row) for row in payments])

    @app.route("/member/login", methods=["GET", "POST"])
    def member_login():
        if request.method == "POST":
            email = request.form.get("email", "").strip().lower()
            row = get_db().execute("SELECT m.member_id,a.password_hash FROM members m "
                                   "JOIN member_accounts a USING(member_id) WHERE lower(m.email)=?", (email,)).fetchone()
            if row and check_password_hash(row["password_hash"], request.form.get("password", "")):
                session.clear()
                session["member_id"] = row["member_id"]
                return redirect(url_for("member_dashboard"))
            flash("We could not match that email and password. Register first if this is your first visit.", "error")
            return render_template("member_login.html"), 401
        return render_template("member_login.html")

    @app.route("/member/register", methods=["GET", "POST"])
    def member_register():
        if request.method == "POST":
            f = request.form
            errs = [v.validate_name(f.get("name")), v.validate_phone(f.get("phone")),
                    v.validate_email(f.get("email")), v.validate_join_date(f.get("join_date"), today()),
                    v.validate_password(f.get("password"))]
            errs = [e for e in errs if e]
            if f.get("password") != f.get("confirm_password"):
                errs.append("Passwords do not match.")
            if errs:
                for error in errs: flash(error, "error")
                return render_template("member_register.html", m=f), 400
            db_ = get_db()
            existing = db_.execute("SELECT * FROM members WHERE lower(email)=?", (f["email"].strip().lower(),)).fetchone()
            if existing and (existing["phone"] != f["phone"].strip() or
                             db_.execute("SELECT 1 FROM member_accounts WHERE member_id=?", (existing["member_id"],)).fetchone()):
                flash("That email is already registered. Contact gym staff if you need account access.", "error")
                return render_template("member_register.html", m=f), 409
            try:
                if existing:
                    mid = existing["member_id"]
                else:
                    cur = db_.execute("INSERT INTO members(name,phone,email,join_date) VALUES(?,?,?,?)",
                                      (f["name"].strip(), f["phone"].strip(), f["email"].strip().lower(), f["join_date"]))
                    mid = cur.lastrowid
                db_.execute("INSERT INTO member_accounts(member_id,password_hash) VALUES(?,?)",
                            (mid, generate_password_hash(f["password"])))
                db_.commit()
            except sqlite3.IntegrityError:
                db_.rollback()
                flash("That phone number or email is already in use.", "error")
                return render_template("member_register.html", m=f), 409
            session.clear()
            session["member_id"] = mid
            return redirect(url_for("member_dashboard"))
        return render_template("member_register.html", m={"join_date": today().isoformat()})

    @app.route("/member/logout")
    def member_logout():
        session.clear()
        return redirect(url_for("member_login"))

    # ---------------- FR2 Member management ----------------
    def validate_member(form):
        errs = [v.validate_name(form.get("name")), v.validate_phone(form.get("phone")),
                v.validate_email(form.get("email")),
                v.validate_join_date(form.get("join_date"), today())]
        return [e for e in errs if e]

    @app.route("/members")
    @login_required
    def members():
        q = request.args.get("q", "").strip()
        sql, args = "SELECT * FROM members", ()
        if q:
            sql += " WHERE name LIKE ? OR phone LIKE ? OR email LIKE ?"
            args = (f"%{q}%",) * 3
        rows = get_db().execute(sql + " ORDER BY member_id", args).fetchall()
        plans = get_db().execute("SELECT * FROM plans ORDER BY name").fetchall()
        return render_template("members.html", members=rows, plans=plans, q=q)

    @app.route("/members/<int:mid>")
    @login_required
    def member_detail(mid):
        db_ = get_db()
        member = db_.execute("SELECT * FROM members WHERE member_id=?", (mid,)).fetchone()
        if not member:
            abort(404)
        memberships = db_.execute("SELECT ms.*,p.name AS plan_name,p.price FROM membership ms "
                                  "JOIN plans p USING(plan_id) WHERE ms.member_id=? "
                                  "ORDER BY ms.end_date DESC", (mid,)).fetchall()
        payments = db_.execute("SELECT p.*,pl.name AS plan_name FROM payments p LEFT JOIN plans pl USING(plan_id) "
                               "WHERE p.member_id=? ORDER BY p.payment_date DESC,p.payment_id DESC", (mid,)).fetchall()
        attendance = db_.execute("SELECT * FROM attendance WHERE member_id=? ORDER BY date DESC LIMIT 20", (mid,)).fetchall()
        member = dict(member)
        member["has_account"] = bool(db_.execute("SELECT 1 FROM member_accounts WHERE member_id=?", (mid,)).fetchone())
        plans = db_.execute("SELECT * FROM plans ORDER BY name").fetchall()
        return render_template("member_detail.html", member=member, memberships=memberships,
                               payments=payments, attendance=attendance, plans=plans, today=today().isoformat())

    @app.route("/members/<int:mid>/payments", methods=["POST"])
    @login_required
    def admin_record_payment(mid):
        db_ = get_db()
        if not db_.execute("SELECT 1 FROM members WHERE member_id=?", (mid,)).fetchone():
            abort(404)
        payment_date = v.parse_date(request.form.get("payment_date"))
        method = request.form.get("method", "")
        plan = db_.execute("SELECT * FROM plans WHERE plan_id=?", (request.form.get("plan_id", ""),)).fetchone()
        if not plan or not payment_date or method not in ("Cash", "Card", "Bank transfer", "UPI"):
            flash("Choose a plan and enter a valid date and payment method.", "error")
            return redirect(url_for("member_detail", mid=mid) + "#payments"), 400
        start, end = activate_paid_membership(db_, mid, plan, method, payment_date)
        flash(f"Payment recorded and {plan['name']} activated from {start.isoformat()} to {end.isoformat()}.", "ok")
        return redirect(url_for("member_detail", mid=mid) + "#payments")

    @app.route("/members/add", methods=["GET", "POST"])
    @login_required
    def add_member():
        if request.method == "POST":
            errs = validate_member(request.form)
            if errs:
                for e in errs: flash(e, "error")
                return render_template("member_form.html", m=request.form, action="Add"), 400
            try:
                f = request.form
                get_db().execute("INSERT INTO members(name,phone,email,join_date) VALUES(?,?,?,?)",
                                 (f["name"].strip(), f["phone"].strip(), f["email"].strip().lower(), f["join_date"].strip()))
                get_db().commit()
            except sqlite3.IntegrityError:
                flash("A member with this phone or email already exists.", "error")
                return render_template("member_form.html", m=request.form, action="Add"), 409
            flash("Member added.", "ok")
            return redirect(url_for("members"))
        return render_template("member_form.html", m={"join_date": today().isoformat()}, action="Add")

    @app.route("/members/<int:mid>/edit", methods=["GET", "POST"])
    @login_required
    def edit_member(mid):
        m = get_db().execute("SELECT * FROM members WHERE member_id=?", (mid,)).fetchone()
        if not m:
            abort(404)
        if request.method == "POST":
            errs = validate_member(request.form)
            if errs:
                for e in errs: flash(e, "error")
                return render_template("member_form.html", m=request.form, action="Edit"), 400
            try:
                f = request.form
                get_db().execute("UPDATE members SET name=?,phone=?,email=?,join_date=? WHERE member_id=?",
                                 (f["name"].strip(), f["phone"].strip(), f["email"].strip().lower(), f["join_date"].strip(), mid))
                get_db().commit()
            except sqlite3.IntegrityError:
                flash("A member with this phone or email already exists.", "error")
                return render_template("member_form.html", m=request.form, action="Edit"), 409
            flash("Member updated.", "ok")
            return redirect(url_for("members"))
        return render_template("member_form.html", m=m, action="Edit")

    @app.route("/members/<int:mid>/delete", methods=["POST"])
    @login_required
    def delete_member(mid):
        cur = get_db().execute("DELETE FROM members WHERE member_id=?", (mid,))
        get_db().commit()
        if cur.rowcount == 0:
            abort(404)
        flash("Member deleted.", "ok")
        return redirect(url_for("members"))

    # ---------------- FR3 Membership plans ----------------
    def validate_plan(form):
        errs = [v.validate_plan_name(form.get("name")), v.validate_duration(form.get("duration_days")),
                v.validate_price(form.get("price"))]
        return [e for e in errs if e]

    @app.route("/plans")
    @login_required
    def plans():
        rows = get_db().execute("SELECT * FROM plans ORDER BY plan_id").fetchall()
        return render_template("plans.html", plans=rows)

    @app.route("/plans/add", methods=["GET", "POST"])
    @login_required
    def add_plan():
        if request.method == "POST":
            errs = validate_plan(request.form)
            if errs:
                for e in errs: flash(e, "error")
                return render_template("plan_form.html", p=request.form, action="Add"), 400
            try:
                f = request.form
                get_db().execute("INSERT INTO plans(name,duration_days,price) VALUES(?,?,?)",
                                 (f["name"].strip(), int(f["duration_days"]), float(f["price"])))
                get_db().commit()
            except sqlite3.IntegrityError:
                flash("A plan with this name already exists.", "error")
                return render_template("plan_form.html", p=request.form, action="Add"), 409
            flash("Plan added.", "ok")
            return redirect(url_for("plans"))
        return render_template("plan_form.html", p={}, action="Add")

    @app.route("/plans/<int:pid>/edit", methods=["GET", "POST"])
    @login_required
    def edit_plan(pid):
        p = get_db().execute("SELECT * FROM plans WHERE plan_id=?", (pid,)).fetchone()
        if not p:
            abort(404)
        if request.method == "POST":
            errs = validate_plan(request.form)
            if errs:
                for e in errs: flash(e, "error")
                return render_template("plan_form.html", p=request.form, action="Edit"), 400
            try:
                f = request.form
                get_db().execute("UPDATE plans SET name=?,duration_days=?,price=? WHERE plan_id=?",
                                 (f["name"].strip(), int(f["duration_days"]), float(f["price"]), pid))
                get_db().commit()
            except sqlite3.IntegrityError:
                flash("A plan with this name already exists.", "error")
                return render_template("plan_form.html", p=request.form, action="Edit"), 409
            flash("Plan updated.", "ok")
            return redirect(url_for("plans"))
        return render_template("plan_form.html", p=p, action="Edit")

    @app.route("/plans/<int:pid>/delete", methods=["POST"])
    @login_required
    def delete_plan(pid):
        try:
            cur = get_db().execute("DELETE FROM plans WHERE plan_id=?", (pid,))
            get_db().commit()
        except sqlite3.IntegrityError:
            flash("Plan is in use by a membership and cannot be deleted.", "error")
            return redirect(url_for("plans")), 409
        if cur.rowcount == 0:
            abort(404)
        flash("Plan deleted.", "ok")
        return redirect(url_for("plans"))

    @app.route("/members/<int:mid>/assign", methods=["POST"])
    @login_required
    def assign_plan(mid):
        db_ = get_db()
        if not db_.execute("SELECT 1 FROM members WHERE member_id=?", (mid,)).fetchone():
            abort(404)
        plan = db_.execute("SELECT * FROM plans WHERE plan_id=?", (request.form.get("plan_id", "0"),)).fetchone()
        if not plan:
            flash("Selected plan does not exist.", "error")
            return redirect(url_for("members")), 400
        raw_start = request.form.get("start_date", "").strip()
        start = v.parse_date(raw_start) if raw_start else today()
        if start is None:
            flash("Start date must be a valid date (YYYY-MM-DD).", "error")
            return redirect(url_for("members")), 400
        end = start + timedelta(days=plan["duration_days"])
        db_.execute("INSERT INTO membership(member_id,plan_id,start_date,end_date) VALUES(?,?,?,?)",
                    (mid, plan["plan_id"], start.isoformat(), end.isoformat()))
        db_.commit()
        flash(f"Plan '{plan['name']}' assigned until {end.isoformat()}.", "ok")
        return redirect(url_for("members"))

    # ---------------- FR4 Attendance ----------------
    def has_active_membership(member_id):
        t = today().isoformat()
        return get_db().execute(
            "SELECT 1 FROM membership WHERE member_id=? AND start_date<=? AND end_date>=?",
            (member_id, t, t)).fetchone() is not None

    def next_membership_start(db_, member_id):
        """Keep renewals sequential, even when a member renews early."""
        last = db_.execute("SELECT MAX(end_date) AS end_date FROM membership WHERE member_id=?",
                           (member_id,)).fetchone()["end_date"]
        if last:
            last_day = v.parse_date(last)
            if last_day and last_day >= today():
                return last_day + timedelta(days=1)
        return today()

    def activate_paid_membership(db_, member_id, plan, method, payment_date=None, status="Paid"):
        """Record payment and membership together so their histories stay linked."""
        start = next_membership_start(db_, member_id)
        end = start + timedelta(days=plan["duration_days"])
        db_.execute("INSERT INTO membership(member_id,plan_id,start_date,end_date) VALUES(?,?,?,?)",
                    (member_id, plan["plan_id"], start.isoformat(), end.isoformat()))
        dbm.save_payment(db_, member_id, plan["price"],
                         (payment_date or today()).isoformat(), method,
                         plan["plan_id"], status, commit=False)
        db_.commit()
        return start, end

    @app.route("/attendance", methods=["GET", "POST"])
    @login_required
    def attendance():
        db_ = get_db()
        if request.method == "POST":
            raw = request.form.get("member_id", "").strip()
            if not raw.isdigit():
                flash("Member ID must be a number.", "error")
                code = 400
            elif not db_.execute("SELECT 1 FROM members WHERE member_id=?", (raw,)).fetchone():
                flash("Member not found.", "error")
                code = 404
            elif not has_active_membership(int(raw)):
                flash("Member has no active membership.", "error")
                code = 403
            else:
                now = datetime.now()
                try:
                    db_.execute("INSERT INTO attendance(member_id,date,time) VALUES(?,?,?)",
                                (int(raw), today().isoformat(), now.strftime("%H:%M:%S")))
                    db_.commit()
                    flash("Attendance recorded.", "ok")
                    return redirect(url_for("attendance"))
                except sqlite3.IntegrityError:
                    flash("Attendance already marked for today.", "error")
                    code = 409
            rows = db_.execute("SELECT a.*, m.name FROM attendance a JOIN members m USING(member_id) ORDER BY attendance_id DESC").fetchall()
            members = db_.execute("SELECT member_id, name FROM members ORDER BY name").fetchall()
            return render_template("attendance.html", rows=rows, members=members), code
        rows = db_.execute("SELECT a.*, m.name FROM attendance a JOIN members m USING(member_id) ORDER BY attendance_id DESC").fetchall()
        members = db_.execute("SELECT member_id, name FROM members ORDER BY name").fetchall()
        return render_template("attendance.html", rows=rows, members=members)

    # ---------------- FR5 Workout selection ----------------
    # These pages use the adapter methods in db.py so the site's workout and
    # payment features can be switched to the database owner's MySQL schema.
    @app.route("/workouts", methods=["GET", "POST"])
    @login_required
    def workouts():
        db_ = get_db()
        categories = dbm.WORKOUT_CATEGORIES
        if request.method == "POST":
            member_id = request.form.get("member_id", "").strip()
            category = request.form.get("category", "").strip()
            if not member_id.isdigit() or not db_.execute(
                    "SELECT 1 FROM members WHERE member_id=?", (member_id,)).fetchone():
                flash("Choose a valid member.", "error")
                return redirect(url_for("workouts")), 400
            if category not in categories:
                flash("Choose a valid workout category.", "error")
                return redirect(url_for("workouts")), 400
            try:
                dbm.save_workout_selection(db_, int(member_id), today().isoformat(), category)
            except sqlite3.IntegrityError:
                flash("This member already selected a workout today.", "error")
                return redirect(url_for("workouts")), 409
            flash("Today's workout was saved.", "ok")
            return redirect(url_for("workouts"))
        members = db_.execute("SELECT member_id,name FROM members ORDER BY name").fetchall()
        selections = dbm.list_workout_selections(db_)
        return render_template("workouts.html", members=members, categories=categories,
                               selections=selections, today=today().isoformat())

    # ---------------- FR6 Workout analytics ----------------
    @app.route("/analytics")
    @login_required
    def analytics():
        data = dbm.workout_analytics(get_db())
        total = sum(item["count"] for item in data)
        for item in data:
            item["percent"] = round(item["count"] * 100 / total, 1) if total else 0
        return render_template("analytics.html", data=data, total=total)

    # ---------------- FR7 Payment records ----------------
    @app.route("/payments", methods=["GET", "POST"])
    @login_required
    def payments():
        db_ = get_db()
        if request.method == "POST":
            member_id = request.form.get("member_id", "").strip()
            payment_date = request.form.get("payment_date", "").strip()
            method = request.form.get("method", "").strip()
            parsed_date = v.parse_date(payment_date)
            methods = ("Cash", "Card", "Bank transfer", "UPI")
            if not member_id.isdigit() or not db_.execute(
                    "SELECT 1 FROM members WHERE member_id=?", (member_id,)).fetchone():
                flash("Choose a valid member.", "error")
                return redirect(url_for("payments")), 400
            plan = db_.execute("SELECT * FROM plans WHERE plan_id=?", (request.form.get("plan_id", ""),)).fetchone()
            if not plan or not parsed_date or not method:
                flash("Choose a plan and enter a valid date and payment method.", "error")
                return redirect(url_for("payments")), 400
            if method not in methods:
                flash("Choose a valid payment method.", "error")
                return redirect(url_for("payments")), 400
            activate_paid_membership(db_, int(member_id), plan, method, parsed_date)
            flash(f"Payment saved and {plan['name']} membership activated.", "ok")
            return redirect(url_for("payments"))
        members = db_.execute("SELECT member_id,name FROM members ORDER BY name").fetchall()
        rows = dbm.list_payments(db_)
        plans = db_.execute("SELECT * FROM plans ORDER BY name").fetchall()
        return render_template("payments.html", members=members, plans=plans, payments=rows,
                               today=today().isoformat())

    # ---------------- Member self-service portal ----------------
    def member_active_plan(member_id):
        return get_db().execute(
            "SELECT ms.*,p.name AS plan_name,p.price,p.duration_days FROM membership ms "
            "JOIN plans p USING(plan_id) WHERE ms.member_id=? AND ms.start_date<=? AND ms.end_date>=? "
            "ORDER BY ms.end_date DESC LIMIT 1",
            (member_id, today().isoformat(), today().isoformat())).fetchone()

    @app.route("/portal")
    @member_required
    def member_dashboard():
        db_ = get_db()
        mid = session["member_id"]
        member = db_.execute("SELECT * FROM members WHERE member_id=?", (mid,)).fetchone()
        if not member:
            session.clear()
            return redirect(url_for("member_login"))
        plan = member_active_plan(mid)
        attendance_count = db_.execute("SELECT COUNT(*) AS n FROM attendance WHERE member_id=?", (mid,)).fetchone()["n"]
        recent = db_.execute("SELECT * FROM attendance WHERE member_id=? ORDER BY date DESC LIMIT 5", (mid,)).fetchall()
        workouts = db_.execute("SELECT * FROM workout_selection WHERE member_id=? ORDER BY date DESC LIMIT 5", (mid,)).fetchall()
        payments = db_.execute("SELECT p.*,pl.name AS plan_name FROM payments p LEFT JOIN plans pl USING(plan_id) "
                               "WHERE p.member_id=? ORDER BY p.payment_date DESC LIMIT 3", (mid,)).fetchall()
        return render_template("member_dashboard.html", member=member, plan=plan,
                               attendance_count=attendance_count, recent=recent,
                               workouts=workouts, payments=payments, today=today().isoformat())

    @app.route("/portal/profile")
    @member_required
    def member_profile():
        db_ = get_db()
        mid = session["member_id"]
        member = db_.execute("SELECT * FROM members WHERE member_id=?", (mid,)).fetchone()
        visits = db_.execute("SELECT COUNT(*) AS n FROM attendance WHERE member_id=?", (mid,)).fetchone()["n"]
        return render_template("member_profile.html", member=member, visits=visits,
                               plan=member_active_plan(mid), today=today().isoformat())

    @app.route("/portal/attendance", methods=["GET", "POST"])
    @member_required
    def member_attendance():
        db_ = get_db()
        mid = session["member_id"]
        if request.method == "POST":
            if not member_active_plan(mid):
                flash("An active membership is required to check in.", "error")
                return redirect(url_for("member_attendance")), 403
            try:
                db_.execute("INSERT INTO attendance(member_id,date,time) VALUES(?,?,?)",
                            (mid, today().isoformat(), datetime.now().strftime("%H:%M:%S")))
                db_.commit()
                flash("You are checked in for today.", "ok")
            except sqlite3.IntegrityError:
                flash("Your attendance is already recorded for today.", "error")
                return redirect(url_for("member_attendance")), 409
            return redirect(url_for("member_attendance"))
        rows = db_.execute("SELECT * FROM attendance WHERE member_id=? ORDER BY date DESC", (mid,)).fetchall()
        return render_template("member_attendance.html", rows=rows, plan=member_active_plan(mid), today=today().isoformat())

    @app.route("/portal/workouts", methods=["GET", "POST"])
    @member_required
    def member_workouts():
        db_ = get_db()
        mid = session["member_id"]
        if request.method == "POST":
            if not member_active_plan(mid):
                flash("Choose an active membership plan before saving a workout.", "error")
                return redirect(url_for("member_payments")), 403
            category = request.form.get("category", "")
            if category not in dbm.WORKOUT_CATEGORIES:
                flash("Choose a valid workout category.", "error")
                return redirect(url_for("member_workouts")), 400
            dbm.set_workout_selection(db_, mid, today().isoformat(), category)
            flash("Today's workout focus updated. You can change it again whenever you need.", "ok")
            return redirect(url_for("member_workouts"))
        rows = db_.execute("SELECT * FROM workout_selection WHERE member_id=? ORDER BY date DESC", (mid,)).fetchall()
        return render_template("member_workouts.html", rows=rows, categories=dbm.WORKOUT_CATEGORIES,
                               today=today().isoformat())

    EXERCISES = {
        "barbell-back-squat": {"name": "Barbell Back Squat", "category": "Legs", "level": "Strength · Intermediate",
                                "image": "images/exercise-squat.png", "cue": "Keep your chest lifted and knees tracking over toes."},
        "dumbbell-bench-press": {"name": "Dumbbell Bench Press", "category": "Chest", "level": "Strength · Beginner",
                                  "image": "images/exercise-bench.png", "cue": "Lower with control, then press evenly through both arms."},
        "treadmill-intervals": {"name": "Treadmill Intervals", "category": "Cardio", "level": "Cardio · All levels",
                                 "image": "images/exercise-cardio.png", "cue": "Alternate one brisk minute with one easy recovery minute."},
    }
    PLAN_CATEGORIES = ("Chest", "Back", "Legs", "Shoulders", "Cardio")
    EXERCISE_STARTERS = {
        "Chest": ("Dumbbell Bench Press", "Incline Dumbbell Press", "Cable Fly"),
        "Back": ("Lat Pulldown", "Seated Cable Row", "One-arm Dumbbell Row"),
        "Legs": ("Barbell Back Squat", "Leg Press", "Leg Curl"),
        "Shoulders": ("Dumbbell Shoulder Press", "Lateral Raise", "Face Pull"),
        "Cardio": ("Treadmill Intervals", "Stationary Bike", "Rowing Intervals"),
    }

    def exercise_plan_fields():
        """Validate the editable personal-plan form and return its values."""
        category = request.form.get("category", "").strip()
        exercise_name = " ".join(request.form.get("exercise_name", "").split())
        reps = request.form.get("reps", "").strip()
        notes = request.form.get("notes", "").strip()
        try:
            sets = int(request.form.get("sets", ""))
        except ValueError:
            sets = 0
        if category not in PLAN_CATEGORIES:
            return None, "Choose Chest, Back, Legs, Shoulders, or Cardio."
        if not 2 <= len(exercise_name) <= 60:
            return None, "Exercise name must contain 2 to 60 characters."
        if not 1 <= sets <= 20:
            return None, "Sets must be between 1 and 20."
        if not reps or len(reps) > 24:
            return None, "Enter a repetition or duration target of up to 24 characters."
        if len(notes) > 240:
            return None, "Notes can contain up to 240 characters."
        return {"category": category, "exercise_name": exercise_name, "sets": sets,
                "reps": reps, "notes": notes}, None

    @app.route("/portal/exercise-plan")
    @member_required
    def member_exercise_plan():
        rows = get_db().execute(
            "SELECT * FROM member_exercise_plan WHERE member_id=? ORDER BY category, exercise_plan_id",
            (session["member_id"],)).fetchall()
        return render_template("member_exercise_plan.html", rows=rows, categories=PLAN_CATEGORIES,
                               starters=EXERCISE_STARTERS, today=today().isoformat())

    @app.route("/portal/exercise-plan/add", methods=["POST"])
    @member_required
    def add_member_exercise_plan():
        values, error = exercise_plan_fields()
        if error:
            flash(error, "error")
            return redirect(url_for("member_exercise_plan")), 400
        try:
            get_db().execute(
                "INSERT INTO member_exercise_plan(member_id,category,exercise_name,sets,reps,notes) VALUES(?,?,?,?,?,?)",
                (session["member_id"], values["category"], values["exercise_name"], values["sets"],
                 values["reps"], values["notes"]))
            get_db().commit()
        except sqlite3.IntegrityError:
            flash("That exercise is already in this category of your plan.", "error")
            return redirect(url_for("member_exercise_plan")), 409
        flash(f"{values['exercise_name']} was added to your {values['category']} plan.", "ok")
        return redirect(url_for("member_exercise_plan"))

    @app.route("/portal/exercise-plan/starter", methods=["POST"])
    @member_required
    def add_starter_exercise():
        category = request.form.get("category", "")
        exercise_name = request.form.get("exercise_name", "")
        if category not in EXERCISE_STARTERS or exercise_name not in EXERCISE_STARTERS[category]:
            abort(400)
        try:
            get_db().execute(
                "INSERT INTO member_exercise_plan(member_id,category,exercise_name,sets,reps,notes) VALUES(?,?,?,?,?,?)",
                (session["member_id"], category, exercise_name, 3, "10", ""))
            get_db().commit()
            flash(f"{exercise_name} was added. Edit it anytime to match your routine.", "ok")
        except sqlite3.IntegrityError:
            flash("That starter exercise is already in your plan.", "error")
        return redirect(url_for("member_exercise_plan"))

    @app.route("/portal/exercise-plan/<int:exercise_plan_id>/edit", methods=["GET", "POST"])
    @member_required
    def edit_member_exercise_plan(exercise_plan_id):
        db_ = get_db()
        item = db_.execute("SELECT * FROM member_exercise_plan WHERE exercise_plan_id=? AND member_id=?",
                           (exercise_plan_id, session["member_id"])).fetchone()
        if not item:
            abort(404)
        if request.method == "POST":
            values, error = exercise_plan_fields()
            if error:
                flash(error, "error")
                return render_template("member_exercise_plan_form.html", item=item, categories=PLAN_CATEGORIES), 400
            try:
                db_.execute("""UPDATE member_exercise_plan
                               SET category=?,exercise_name=?,sets=?,reps=?,notes=?
                               WHERE exercise_plan_id=? AND member_id=?""",
                            (values["category"], values["exercise_name"], values["sets"], values["reps"],
                             values["notes"], exercise_plan_id, session["member_id"]))
                db_.commit()
            except sqlite3.IntegrityError:
                flash("That exercise is already in this category of your plan.", "error")
                return render_template("member_exercise_plan_form.html", item=item, categories=PLAN_CATEGORIES), 409
            flash("Your exercise was updated.", "ok")
            return redirect(url_for("member_exercise_plan"))
        return render_template("member_exercise_plan_form.html", item=item, categories=PLAN_CATEGORIES)

    @app.route("/portal/exercise-plan/<int:exercise_plan_id>/delete", methods=["POST"])
    @member_required
    def delete_member_exercise_plan(exercise_plan_id):
        cur = get_db().execute("DELETE FROM member_exercise_plan WHERE exercise_plan_id=? AND member_id=?",
                               (exercise_plan_id, session["member_id"]))
        get_db().commit()
        if not cur.rowcount:
            abort(404)
        flash("Exercise removed from your plan.", "ok")
        return redirect(url_for("member_exercise_plan"))

    @app.route("/portal/exercise-plan/<int:exercise_plan_id>/start", methods=["POST"])
    @member_required
    def start_member_exercise_plan(exercise_plan_id):
        mid = session["member_id"]
        item = get_db().execute("SELECT * FROM member_exercise_plan WHERE exercise_plan_id=? AND member_id=?",
                                (exercise_plan_id, mid)).fetchone()
        if not item:
            abort(404)
        if not member_active_plan(mid):
            flash("Choose an active membership plan before starting an exercise.", "error")
            return redirect(url_for("member_payments")), 403
        dbm.set_workout_selection(get_db(), mid, today().isoformat(), item["category"])
        flash(f"{item['exercise_name']} is set as today's {item['category']} focus. You can switch it anytime.", "ok")
        return redirect(url_for("member_exercise_plan"))

    @app.route("/portal/exercises")
    @member_required
    def member_exercises():
        return render_template("member_exercises.html", exercises=EXERCISES, today=today().isoformat())

    @app.route("/portal/exercises/<slug>/start", methods=["POST"])
    @member_required
    def start_exercise(slug):
        exercise = EXERCISES.get(slug)
        if not exercise:
            abort(404)
        mid = session["member_id"]
        if not member_active_plan(mid):
            flash("Choose an active membership plan before starting an exercise.", "error")
            return redirect(url_for("member_payments")), 403
        dbm.set_workout_selection(get_db(), mid, today().isoformat(), exercise["category"])
        flash(f"{exercise['name']} is set as today's {exercise['category']} workout. You can switch it anytime.", "ok")
        return redirect(url_for("member_exercise_plan"))

    @app.route("/portal/payments", methods=["GET", "POST"])
    @member_required
    def member_payments():
        db_ = get_db()
        mid = session["member_id"]
        if request.method == "POST":
            plan_id = request.form.get("plan_id", "")
            method = request.form.get("method", "")
            if not plan_id.isdigit() or method not in ("Demo card", "Demo UPI", "Cash at desk"):
                flash("Choose a plan and demo payment method.", "error")
                return redirect(url_for("member_payments")), 400
            plan = db_.execute("SELECT * FROM plans WHERE plan_id=?", (plan_id,)).fetchone()
            if not plan:
                abort(404)
            session["checkout"] = {"plan_id": plan["plan_id"], "method": method}
            return redirect(url_for("member_payment_checkout"))
        plans = db_.execute("SELECT * FROM plans ORDER BY duration_days,price").fetchall()
        rows = db_.execute("SELECT p.*,pl.name AS plan_name FROM payments p LEFT JOIN plans pl USING(plan_id) "
                           "WHERE p.member_id=? ORDER BY p.payment_date DESC,p.payment_id DESC", (mid,)).fetchall()
        return render_template("member_payments.html", plans=plans, payments=rows,
                               active=member_active_plan(mid), today=today().isoformat())

    @app.route("/portal/payments/checkout", methods=["GET", "POST"])
    @member_required
    def member_payment_checkout():
        checkout = session.get("checkout")
        if not checkout:
            flash("Choose a plan before opening the demo checkout.", "error")
            return redirect(url_for("member_payments"))
        db_ = get_db()
        plan = db_.execute("SELECT * FROM plans WHERE plan_id=?", (checkout["plan_id"],)).fetchone()
        if not plan:
            session.pop("checkout", None)
            flash("That plan is no longer available.", "error")
            return redirect(url_for("member_payments"))
        if request.method == "POST":
            try:
                start, end = activate_paid_membership(db_, session["member_id"], plan,
                                                      checkout["method"], status="Demo paid")
            except Exception:
                db_.rollback()
                raise
            session.pop("checkout", None)
            flash(f"Demo payment confirmed. {plan['name']} is active from {start.isoformat()} to {end.isoformat()}.", "ok")
            return redirect(url_for("member_payments"))
        return render_template("payment_checkout.html", plan=plan, method=checkout["method"],
                               today=today().isoformat())

    return app


if __name__ == "__main__":
    app = create_app()
    if "--seed-demo" in sys.argv:
        created = dbm.seed_demo_data(app.config["DATABASE"])
        print("Demo presentation data added." if created else "Demo presentation data already exists.")
    else:
        app.run(debug=False)
