import os
import sqlite3
from datetime import date, timedelta
from werkzeug.security import generate_password_hash

SCHEMA = """
CREATE TABLE IF NOT EXISTS admin(
  admin_id INTEGER PRIMARY KEY AUTOINCREMENT,
  username TEXT NOT NULL UNIQUE,
  password TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS login_attempts(
  username TEXT PRIMARY KEY,
  failed INTEGER NOT NULL DEFAULT 0,
  locked_until REAL NOT NULL DEFAULT 0);
CREATE TABLE IF NOT EXISTS members(
  member_id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  phone TEXT NOT NULL UNIQUE,
  email TEXT NOT NULL UNIQUE,
  join_date TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS plans(
  plan_id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL UNIQUE,
  duration_days INTEGER NOT NULL,
  price REAL NOT NULL);
CREATE TABLE IF NOT EXISTS membership(
  membership_id INTEGER PRIMARY KEY AUTOINCREMENT,
  member_id INTEGER NOT NULL REFERENCES members(member_id) ON DELETE CASCADE,
  plan_id INTEGER NOT NULL REFERENCES plans(plan_id) ON DELETE RESTRICT,
  start_date TEXT NOT NULL,
  end_date TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS attendance(
  attendance_id INTEGER PRIMARY KEY AUTOINCREMENT,
  member_id INTEGER NOT NULL REFERENCES members(member_id) ON DELETE CASCADE,
  date TEXT NOT NULL,
  time TEXT NOT NULL,
  UNIQUE(member_id, date));
CREATE TABLE IF NOT EXISTS workout_selection(
  selection_id INTEGER PRIMARY KEY AUTOINCREMENT,
  member_id INTEGER NOT NULL REFERENCES members(member_id) ON DELETE CASCADE,
  date TEXT NOT NULL,
  category TEXT NOT NULL,
  UNIQUE(member_id, date));
CREATE TABLE IF NOT EXISTS member_exercise_plan(
  exercise_plan_id INTEGER PRIMARY KEY AUTOINCREMENT,
  member_id INTEGER NOT NULL REFERENCES members(member_id) ON DELETE CASCADE,
  category TEXT NOT NULL,
  exercise_name TEXT NOT NULL,
  sets INTEGER NOT NULL DEFAULT 3 CHECK(sets BETWEEN 1 AND 20),
  reps TEXT NOT NULL DEFAULT '10',
  notes TEXT NOT NULL DEFAULT '',
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(member_id, category, exercise_name));
CREATE TABLE IF NOT EXISTS payments(
  payment_id INTEGER PRIMARY KEY AUTOINCREMENT,
  member_id INTEGER NOT NULL REFERENCES members(member_id) ON DELETE RESTRICT,
  plan_id INTEGER REFERENCES plans(plan_id) ON DELETE SET NULL,
  amount REAL NOT NULL CHECK(amount > 0),
  payment_date TEXT NOT NULL,
  method TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'Recorded');
CREATE TABLE IF NOT EXISTS member_accounts(
  member_id INTEGER PRIMARY KEY REFERENCES members(member_id) ON DELETE CASCADE,
  password_hash TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
"""

WORKOUT_CATEGORIES = ("Chest", "Back", "Legs", "Shoulders", "Arms", "Cardio", "Abs")


def save_workout_selection(conn, member_id, day, category):
    """Persistence boundary for the workout-selection feature."""
    conn.execute("INSERT INTO workout_selection(member_id,date,category) VALUES(?,?,?)",
                 (member_id, day, category))
    conn.commit()


def set_workout_selection(conn, member_id, day, category):
    """Set or replace a member's focus for a day, so it can be changed manually."""
    conn.execute("""INSERT INTO workout_selection(member_id,date,category) VALUES(?,?,?)
                 ON CONFLICT(member_id,date) DO UPDATE SET category=excluded.category""",
                 (member_id, day, category))
    conn.commit()


def list_workout_selections(conn):
    return conn.execute("SELECT w.*,m.name FROM workout_selection w JOIN members m USING(member_id) "
                        "ORDER BY w.date DESC,w.selection_id DESC").fetchall()


def workout_analytics(conn):
    rows = conn.execute("SELECT category,COUNT(*) AS count FROM workout_selection "
                         "GROUP BY category ORDER BY category").fetchall()
    counts = {row["category"]: row["count"] for row in rows}
    return [{"category": category, "count": counts.get(category, 0)}
            for category in WORKOUT_CATEGORIES]


def save_payment(conn, member_id, amount, payment_date, method, plan_id=None, status="Recorded", commit=True):
    """Persistence boundary for recording a payment; no payment gateway is used."""
    conn.execute("INSERT INTO payments(member_id,plan_id,amount,payment_date,method,status) VALUES(?,?,?,?,?,?)",
                 (member_id, plan_id, amount, payment_date, method, status))
    if commit:
        conn.commit()


def list_payments(conn):
    return conn.execute("SELECT p.*,m.name,pl.name AS plan_name FROM payments p JOIN members m USING(member_id) "
                        "LEFT JOIN plans pl USING(plan_id) "
                        "ORDER BY p.payment_date DESC,p.payment_id DESC").fetchall()


def connect(path):
    conn = sqlite3.connect(path)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def init_db(path, default_user="admin", default_pw="admin123"):
    parent = os.path.dirname(os.path.abspath(path))
    os.makedirs(parent, exist_ok=True)
    conn = connect(path)
    conn.executescript(SCHEMA)
    # Migrate demo databases created by the earlier Phase 4 website copy.
    payment_columns = {row["name"] for row in conn.execute("PRAGMA table_info(payments)")}
    if "plan_id" not in payment_columns:
        conn.execute("ALTER TABLE payments ADD COLUMN plan_id INTEGER REFERENCES plans(plan_id) ON DELETE SET NULL")
    if "status" not in payment_columns:
        conn.execute("ALTER TABLE payments ADD COLUMN status TEXT NOT NULL DEFAULT 'Recorded'")
    if not conn.execute("SELECT 1 FROM admin LIMIT 1").fetchone():
        conn.execute("INSERT INTO admin(username,password) VALUES(?,?)",
                     (default_user, generate_password_hash(default_pw)))
    conn.commit()
    conn.close()


def seed_demo_data(path):
    """Add one clearly labelled, repeat-safe member journey for a lab presentation."""
    conn = connect(path)
    demo_email = "demo.member@gymsphere.local"
    member = conn.execute("SELECT * FROM members WHERE email=?", (demo_email,)).fetchone()
    if member:
        conn.close()
        return False

    today = date.today()
    plan = conn.execute("SELECT * FROM plans WHERE name=?", ("Demo Premium",)).fetchone()
    if not plan:
        cur = conn.execute("INSERT INTO plans(name,duration_days,price) VALUES(?,?,?)",
                           ("Demo Premium", 30, 1499.0))
        plan_id = cur.lastrowid
    else:
        plan_id = plan["plan_id"]
    cur = conn.execute("INSERT INTO members(name,phone,email,join_date) VALUES(?,?,?,?)",
                       ("Demo Member", "9876500001", demo_email, (today - timedelta(days=12)).isoformat()))
    member_id = cur.lastrowid
    conn.execute("INSERT INTO member_accounts(member_id,password_hash) VALUES(?,?)",
                 (member_id, generate_password_hash("member123")))
    start = today - timedelta(days=12)
    end = start + timedelta(days=30)
    conn.execute("INSERT INTO membership(member_id,plan_id,start_date,end_date) VALUES(?,?,?,?)",
                 (member_id, plan_id, start.isoformat(), end.isoformat()))
    conn.execute("INSERT INTO payments(member_id,plan_id,amount,payment_date,method,status) VALUES(?,?,?,?,?,?)",
                 (member_id, plan_id, 1499.0, start.isoformat(), "Demo UPI", "Demo paid"))
    for offset, category in ((10, "Chest"), (8, "Cardio"), (6, "Back"), (4, "Legs"), (2, "Shoulders")):
        day = today - timedelta(days=offset)
        conn.execute("INSERT INTO attendance(member_id,date,time) VALUES(?,?,?)",
                     (member_id, day.isoformat(), "18:15:00"))
        conn.execute("INSERT INTO workout_selection(member_id,date,category) VALUES(?,?,?)",
                     (member_id, day.isoformat(), category))
    conn.commit()
    conn.close()
    return True
