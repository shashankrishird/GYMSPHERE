# GymSphere backend and database

The Flask backend is implemented in the project root (`app.py`) and its SQLite persistence layer is `db.py`. The default database is stored at `backend/data/gymsphere.db`; set the `DATABASE` Flask config value to use a different SQLite file. The database is initialized and migrated when the app starts.

`schema.sql` documents the SQLite schema used by `db.py`. No payment gateway is connected; payment rows are local demo records.

Run the app from the project root with `python app.py`.
