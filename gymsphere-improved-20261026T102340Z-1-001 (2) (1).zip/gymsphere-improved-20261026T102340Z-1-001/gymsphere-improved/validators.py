"""Pure validation functions (no database, no Flask) - easy to unit test."""
import re
from datetime import date, datetime

NAME_MIN, NAME_MAX = 2, 50
PLAN_NAME_MIN, PLAN_NAME_MAX = 2, 30
DURATION_MIN, DURATION_MAX = 1, 365
PRICE_MIN, PRICE_MAX = 1, 100000
PASSWORD_MIN = 6

_NAME_RE = re.compile(r"^[A-Za-z][A-Za-z .'-]*$")
_PHONE_RE = re.compile(r"^[6-9][0-9]{9}$")
_EMAIL_RE = re.compile(r"^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$")


def validate_name(name):
    name = (name or "").strip()
    if not (NAME_MIN <= len(name) <= NAME_MAX):
        return f"Name must be {NAME_MIN}-{NAME_MAX} characters."
    if not _NAME_RE.match(name):
        return "Name may contain only letters, spaces, . ' -"
    return None


def validate_phone(phone):
    if not _PHONE_RE.match((phone or "").strip()):
        return "Phone must be 10 digits and start with 6-9."
    return None


def validate_email(email):
    email = (email or "").strip()
    if len(email) > 100 or not _EMAIL_RE.match(email):
        return "Enter a valid email address."
    return None


def parse_date(value):
    try:
        return datetime.strptime((value or "").strip(), "%Y-%m-%d").date()
    except ValueError:
        return None


def validate_join_date(value, today=None):
    today = today or date.today()
    d = parse_date(value)
    if d is None:
        return "Join date must be a valid date (YYYY-MM-DD)."
    if d > today:
        return "Join date cannot be in the future."
    return None


def validate_plan_name(name):
    name = (name or "").strip()
    if not (PLAN_NAME_MIN <= len(name) <= PLAN_NAME_MAX):
        return f"Plan name must be {PLAN_NAME_MIN}-{PLAN_NAME_MAX} characters."
    return None


def validate_duration(value):
    text = str(value).strip()
    if not text.isascii():
        return "Duration must be a whole number of days."
    try:
        n = int(text)
    except (ValueError, TypeError):
        return "Duration must be a whole number of days."
    if not (DURATION_MIN <= n <= DURATION_MAX):
        return f"Duration must be {DURATION_MIN}-{DURATION_MAX} days."
    return None


def validate_price(value):
    text = str(value).strip()
    if not text.isascii():
        return "Price must be a number."
    try:
        n = float(text)
    except (ValueError, TypeError):
        return "Price must be a number."
    if not (PRICE_MIN <= n <= PRICE_MAX):
        return f"Price must be between {PRICE_MIN} and {PRICE_MAX}."
    return None


def validate_password(pw):
    if pw is None or len(pw) < PASSWORD_MIN:
        return f"Password must be at least {PASSWORD_MIN} characters."
    return None
